import os
import sys
import argparse
import time

from src.logger import get_logger, log_section, log_subsection, log_result
from src.utils import EmbeddingManager
from src.extractor import ContentExtractor
from src.template_analyzer import analyze_all_templates, save_template_analysis
from src.scorer import TemplateScorer
from src.generator import PresentationGenerator


BANNER = r"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   EZ Works — PPTX Template-Based Presentation Generator       ║
║   ─────────────────────────────────────────────────────────   ║
║                        
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"""

DEFAULT_INPUT = "input/default_input.pptx"
TEMPLATE_DIR = "templates"
OUTPUT_DIR = "output"


# ═══════════════════════════════════════════════════════════════
#  STEP A: Template Sourcing — generate or bring-your-own
# ═══════════════════════════════════════════════════════════════

def setup_templates(args, log):
    """
    Ask user whether to generate sample templates or use their own.
    Returns the template directory path.
    """
    template_dir = args.templates

    if args.auto:
        # In auto mode, generate if folder is empty, otherwise use existing
        existing = [
            f for f in os.listdir(template_dir)
            if f.endswith(".pptx") and not f.startswith("~$")
        ] if os.path.isdir(template_dir) else []
        if not existing:
            log.info("Auto mode: No templates found — generating samples...")
            _generate_samples(log)
        else:
            log.info(f"Auto mode: Using {len(existing)} existing templates in {template_dir}/")
        return template_dir

    # Interactive mode
    log_subsection("Template Setup")

    existing = [
        f for f in os.listdir(template_dir)
        if f.endswith(".pptx") and not f.startswith("~$")
    ] if os.path.isdir(template_dir) else []

    if existing:
        print(f"\n  Found {len(existing)} template(s) in {template_dir}/:")
        for f in existing:
            print(f"    • {f}")
        print()
        print("  Options:")
        print("    [1] Use these existing templates")
        print("    [2] Add your own templates (I'll show you where)")
        print("    [3] Regenerate sample templates (overwrites existing)")
        choice = input("\n  Select [1/2/3]: ").strip()
    else:
        print(f"\n  No templates found in {template_dir}/.")
        print()
        print("  Options:")
        print("    [1] Generate sample templates automatically")
        print("    [2] I want to add my own templates")
        choice = input("\n  Select [1/2]: ").strip()

    if choice == "2":
        # User wants to add their own
        os.makedirs(template_dir, exist_ok=True)
        print()
        print("  ┌─────────────────────────────────────────────────────┐")
        print(f"  │  Please place your .pptx template files in:         │")
        print(f"  │                                                     │")
        print(f"  │    📁 {os.path.abspath(template_dir):<43}│")
        print(f"  │                                                     │")
        print(f"  │  Each template should have multiple slide layouts    │")
        print(f"  │  with different structures (title, content, table,   │")
        print(f"  │  multi-column, etc.)                                │")
        print("  └─────────────────────────────────────────────────────┘")
        print()
        input("  Press ENTER once you've added your templates... ")

        new_files = [f for f in os.listdir(template_dir) if f.endswith(".pptx")]
        if not new_files:
            print(f"\n  ⚠ Still no .pptx files found in {template_dir}/")
            print("    Falling back to generating sample templates...")
            _generate_samples(log)
        else:
            log.info(f"✓ Found {len(new_files)} user-provided templates")
            for f in new_files:
                log.info(f"  • {f}")

    elif choice == "3" or (not existing and choice == "1"):
        _generate_samples(log)
    else:
        log.info(f"Using {len(existing)} existing templates")

    return template_dir


def _generate_samples(log):
    """Run the sample generator."""
    log.info("Generating sample input + templates...")
    try:
        from generate_samples import main as gen_main
        gen_main()
    except ImportError:
        log.error("generate_samples.py not found! Please ensure it's in the project root.")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════
#  STEP B: Input file selection
# ═══════════════════════════════════════════════════════════════

def get_input_path(args, log):
    """Determine which input PPTX to use."""
    if args.input:
        path = args.input
        if not os.path.exists(path):
            log.error(f"File not found: {path}")
            sys.exit(1)
        return path

    if args.auto:
        if os.path.exists(DEFAULT_INPUT):
            return DEFAULT_INPUT
        log.error(f"Default input not found. Run 'python generate_samples.py' first.")
        sys.exit(1)

    # Interactive
    log_subsection("Input Selection")
    input_files = [
        f for f in os.listdir("input")
        if f.endswith(".pptx") and not f.startswith("~$")
    ] if os.path.isdir("input") else []

    if input_files:
        print(f"\n  Found {len(input_files)} file(s) in input/:")
        for i, f in enumerate(input_files):
            marker = " (default)" if f == "default_input.pptx" else ""
            print(f"    [{i + 1}] {f}{marker}")
        print(f"    [C] Enter custom path")

        choice = input("\n  Select option: ").strip()
        if choice.upper() == "C":
            path = input("  Enter PPTX path: ").strip()
            if not os.path.exists(path):
                log.error(f"File not found: {path}")
                sys.exit(1)
            return path
        try:
            idx = int(choice) - 1
            return os.path.join("input", input_files[idx])
        except (ValueError, IndexError):
            return os.path.join("input", input_files[0])
    else:
        print("  No files found in input/.")
        path = input("  Enter PPTX path: ").strip()
        if not os.path.exists(path):
            log.error(f"File not found: {path}")
            sys.exit(1)
        return path


# ═══════════════════════════════════════════════════════════════
#  STEP C: Scoring weights configuration
# ═══════════════════════════════════════════════════════════════

DYNAMIC_SIGNALS = [
    "column_match", "zone_count_fit", "table_fit",
    "spatial_overlap", "semantic_role_fit", "layout_type_match",
]


def get_scoring_weights(args, log):
    """
    Ask user for custom weights or let the scorer derive them dynamically.
    Returns None (for dynamic) or a dict of custom weights.
    """
    if args.auto:
        log.info("Auto mode: Weights will be derived dynamically from input content")
        return None  # scorer will compute dynamic weights

    log_subsection("Scoring Weights Configuration")

    print("\n  The scoring engine can automatically derive weights from your")
    print("  input content (e.g. table-heavy input → table_fit weighted higher).")
    print()
    print("  Options:")
    print("    [A] Auto — derive weights dynamically from content (recommended)")
    print("    [C] Custom — manually set weights for each scoring signal")

    choice = input("\n  Select [A/C]: ").strip().upper()

    if choice != "C":
        log.info("Weights will be derived dynamically from input content")
        return None

    # Custom weights flow
    print("\n  6 scoring signals — enter weight for each (0-100).")
    print("  Values are normalized to sum to 100%. Press ENTER for equal weight.\n")

    raw_weights = {}
    for signal in DYNAMIC_SIGNALS:
        while True:
            val = input(f"    {signal:<22} [default=equal]: ").strip()
            if not val:
                raw_weights[signal] = 100.0 / len(DYNAMIC_SIGNALS)
                break
            try:
                v = float(val.replace("%", ""))
                if 0 <= v <= 100:
                    raw_weights[signal] = v
                    break
                else:
                    print("      Enter a value between 0 and 100.")
            except ValueError:
                print("      Invalid number.")

    total = sum(raw_weights.values())
    if total == 0:
        log.warning("All weights zero — falling back to dynamic")
        return None

    weights = {k: round(v / total, 4) for k, v in raw_weights.items()}
    diff = 1.0 - sum(weights.values())
    if abs(diff) > 0.0001:
        weights[DYNAMIC_SIGNALS[0]] = round(weights[DYNAMIC_SIGNALS[0]] + diff, 4)

    print("\n  Your custom weights (normalized):")
    print("  ─────────────────────────────────────────")
    for signal, weight in weights.items():
        pct = int(weight * 100)
        bar = "█" * (pct // 3) + "░" * (33 - pct // 3)
        print(f"    {signal:<22} {bar} {pct}%")

    log.info(f"Custom weights: {weights}")
    return weights


# ═══════════════════════════════════════════════════════════════
#  MAIN PIPELINE
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="EZ Works PPTX Template-Based Presentation Generator"
    )
    parser.add_argument("--input", "-i", help="Path to input PPTX file")
    parser.add_argument("--templates", "-t", default=TEMPLATE_DIR,
                        help="Directory containing template PPTX files")
    parser.add_argument("--output", "-o", default=OUTPUT_DIR,
                        help="Output directory")
    parser.add_argument("--auto", "-a", action="store_true",
                        help="Non-interactive mode with defaults")
    args = parser.parse_args()

    # Ensure directories exist
    for d in ["input", "templates", "output", "output/assets"]:
        os.makedirs(d, exist_ok=True)

    # Initialize logger (creates log file immediately)
    log = get_logger()

    print(BANNER)
    log.debug("Pipeline started")
    log.debug(f"Args: {vars(args)}")
    start_time = time.time()

    # ── Step A: Template sourcing ───────────────────────────────
    log_section("SETUP: Templates")
    template_dir = setup_templates(args, log)

    # Verify templates exist
    tmpl_files = [
        f for f in os.listdir(template_dir)
        if f.endswith(".pptx") and not f.startswith("~$")
    ]
    if not tmpl_files:
        log.error(f"No templates found in {template_dir}/")
        log.error("Run 'python generate_samples.py' or add your own templates.")
        sys.exit(1)
    log.info(f"Templates ready: {len(tmpl_files)} files in {template_dir}/")

    # ── Step B: Input selection ─────────────────────────────────
    log_section("SETUP: Input Presentation")
    input_path = get_input_path(args, log)
    log_result("Input file", input_path)

    # ── Step C: Scoring weights ─────────────────────────────────
    log_section("SETUP: Scoring Weights")
    weights = get_scoring_weights(args, log)

    # Initialize shared embedding manager
    emb = EmbeddingManager()

    # ═══ PART 1: Content Extraction ═══════════════════════════
    log_section("PART 1: Content Extraction")
    extractor = ContentExtractor(input_path, emb)
    extracted = extractor.extract()
    extractor.save_json(os.path.join(args.output, "extracted_content.json"))

    for slide in extracted["slides"]:
        fp = slide["fingerprint"]
        log.debug(
            f"  Slide {slide['slide_number']}: "
            f"cols={fp['column_pattern']}, blocks={fp['text_block_count']}, "
            f"tables={fp['table_count']}, roles={fp['semantic_roles']}"
        )

    # ═══ PART 2: Template Analysis ════════════════════════════
    log_section("PART 2: Template Analysis")
    analyses = analyze_all_templates(template_dir, emb)
    save_template_analysis(analyses, os.path.join(args.output, "template_analysis.json"))

    # ═══ PART 3: Template Selection ═══════════════════════════
    log_section("PART 3: Template Selection (Weighted Scoring)")
    scorer = TemplateScorer(extracted, analyses, emb, custom_weights=weights)
    scores = scorer.score_all()
    report = scorer.save_report(os.path.join(args.output, "scoring_report.json"))

    best = scorer.get_best_template()
    log.info("")
    log_result("★ Selected", best["template_name"])
    log_result("  Score", f"{best['total_score']:.4f}")
    log_result("  Reasoning", report["selection_reasoning"])

    # ═══ PART 4: Final Presentation Generation ═════════════════
    log_section("PART 4: Generate Output from Selected Template")
    log.info(f"Strategy: Fill template slots with extracted content")
    log.info(f"Template: {best['template_name']}")

    best_analysis = None
    for a in analyses:
        if a["template_name"] == best["template_name"]:
            best_analysis = a
            break

    if not best_analysis:
        log.error("Could not find analysis for selected template!")
        sys.exit(1)

    from src.generator import PresentationGenerator
    generator = PresentationGenerator(
        extracted, best_analysis, best["template_path"], emb,
        slide_assignments=best.get("assignments")
    )
    output_path = generator.generate(os.path.join(args.output, "final_presentation.pptx"))

    # Generate all-templates preview
    log_subsection("All-Templates Preview")
    preview_path = generator.generate_all_preview(
        all_template_paths=[s["template_path"] for s in scores],
        scores=scores,
        output_path=os.path.join(args.output, "all_templates_preview.pptx")
    )

    # ═══ DONE ═════════════════════════════════════════════════
    elapsed = time.time() - start_time

    log_section("PIPELINE COMPLETE")
    log.info("")
    log_result("Time elapsed", f"{elapsed:.1f}s")
    log_result("Log file", "output/pipeline.log")
    log.info("")
    log.info("Output files:")
    outputs = [
        os.path.join(args.output, "extracted_content.json"),
        os.path.join(args.output, "template_analysis.json"),
        os.path.join(args.output, "scoring_report.json"),
        os.path.join(args.output, "selected_template.txt"),
        output_path,
        preview_path,
        "output/pipeline.log",
    ]
    for o in outputs:
        log.info(f"  📄 {o}")
    log.info("")
    log.debug(f"Pipeline completed in {elapsed:.1f}s")


if __name__ == "__main__":
    main()