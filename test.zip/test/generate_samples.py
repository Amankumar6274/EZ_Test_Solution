"""
generate_samples.py
====================
Creates:
  1. A plain input PPTX (simple text/table grid — the DATA)
  2. 5 rich template PPTX files (visual RECIPES for rendering that data)

The input is deliberately simple. The templates are deliberately rich.
The pipeline's job: extract data from input → render it in the template style.
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

for d in ["input", "templates", "output"]:
    os.makedirs(d, exist_ok=True)

SW, SH = Inches(13.333), Inches(7.5)

# ── Shared palette ──────────────────────────────────────────
PRIMARY    = RGBColor(0x1B, 0x5E, 0x20)
PRIMARY_LT = RGBColor(0xE8, 0xF5, 0xE9)
ACCENT     = RGBColor(0xC8, 0xA2, 0x2C)
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
BG_LIGHT   = RGBColor(0xF5, 0xF5, 0xF5)
BG_WHITE   = RGBColor(0xFF, 0xFF, 0xFF)
BORDER     = RGBColor(0xE0, 0xE0, 0xE0)
TEXT_DARK  = RGBColor(0x2D, 0x2D, 0x2D)
TEXT_MID   = RGBColor(0x6B, 0x6B, 0x6B)
TEXT_LIGHT = RGBColor(0x9E, 0x9E, 0x9E)
DARK_GREEN = RGBColor(0x14, 0x42, 0x16)
FONT_H     = "Calibri Light"
FONT_B     = "Calibri"

# ── Content data ────────────────────────────────────────────
HEADERS = ["Presentation\nDesign", "Language\nServices", "Research &\nAnalytics",
           "Data\nProcessing", "AI & Tech\nDevelopment"]

ROW1_LABEL = "Point 1"
ROW1 = [
    "Corporate decks\nPitch presentations\nInfographic design\nAnnual reports",
    "Translation (50+ langs)\nSubtitling & dubbing\nLocalization\nTranscription",
    "Market research\nCompetitive analysis\nData visualization\nForecasting models",
    "Data entry & cleanup\nOCR processing\nDatabase management\nDocument digitization",
    "Custom AI solutions\nWorkflow automation\nChatbot development\nML model training",
]

ROW2_LABEL = "Point 2"
ROW2 = [
    "500+ projects/month\nFortune 500 clients",
    "50+ language pairs\n24-hour turnaround",
    "100+ analysts\nISO certified process",
    "99.9% accuracy\nScalable teams",
    "GPT & LLM expertise\nEnd-to-end delivery",
]

SLIDE_TITLE = "Our Service Lines"
FOOTER_L = "شركة سوق الكربون الطوعي الاقليمية"
FOOTER_R = "Regional Voluntary Carbon Market Company"


# ── Shape helpers ───────────────────────────────────────────
def _bg(s, c):
    f = s.background.fill; f.solid(); f.fore_color.rgb = c

def _r(s, l, t, w, h, fill, border=None, bw=0.75):
    sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(l), Inches(t), Inches(w), Inches(h))
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    if border: sh.line.color.rgb = border; sh.line.width = Pt(bw)
    else: sh.line.fill.background()
    return sh

def _rr(s, l, t, w, h, fill, border=None, bw=0.75):
    sh = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(l), Inches(t), Inches(w), Inches(h))
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    if border: sh.line.color.rgb = border; sh.line.width = Pt(bw)
    else: sh.line.fill.background()
    return sh

def _o(s, l, t, sz, fill, border=None):
    sh = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(l), Inches(t), Inches(sz), Inches(sz))
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    if border: sh.line.color.rgb = border; sh.line.width = Pt(1.5)
    else: sh.line.fill.background()
    return sh

def _t(s, l, t, w, h, text, sz=14, bold=False, color=TEXT_DARK,
       align=PP_ALIGN.LEFT, font=FONT_B, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = s.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    tf = tb.text_frame; tf.word_wrap = wrap; tf.vertical_anchor = anchor
    tf.margin_left = Inches(0.05); tf.margin_right = Inches(0.05)
    tf.margin_top = Inches(0.03); tf.margin_bottom = Inches(0.03)
    p = tf.paragraphs[0]; p.text = text; p.alignment = align
    p.font.name = font; p.font.size = Pt(sz); p.font.bold = bold; p.font.color.rgb = color
    return tb

def _mt(s, l, t, w, h, lines, sz=10, color=TEXT_DARK, align=PP_ALIGN.CENTER, font=FONT_B):
    """Multi-paragraph text box."""
    tb = s.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.TOP
    tf.margin_left = Inches(0.05); tf.margin_right = Inches(0.05)
    for i, line in enumerate(lines.split("\n")):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line; p.alignment = align
        p.font.name = font; p.font.size = Pt(sz); p.font.color.rgb = color
    return tb

def _footer_bar(s, left_text, right_text):
    _t(s, 0.3, 7.0, 5, 0.3, left_text, sz=8, color=PRIMARY, font="Arial")
    _t(s, 0.3, 7.18, 5, 0.2, right_text, sz=7, color=PRIMARY, font="Arial")


# ═══════════════════════════════════════════════════════════
#  INPUT — Plain text grid (deliberately simple)
# ═══════════════════════════════════════════════════════════

def create_input():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH

    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    # Title
    _t(s, 0.5, 0.3, 5, 0.5, SLIDE_TITLE, sz=22, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.78, 12.3, 0.03, ACCENT)

    # Column headers
    col_w = 2.2
    gap = 0.25
    start_x = 2.0
    for i, hdr in enumerate(HEADERS):
        x = start_x + i * (col_w + gap)
        _t(s, x, 1.2, col_w, 0.6, hdr.replace("\n", " "),
           sz=14, bold=True, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    # Row labels + content
    for row_idx, (label, cells) in enumerate([(ROW1_LABEL, ROW1), (ROW2_LABEL, ROW2)]):
        y_base = 2.2 + row_idx * 2.4
        _t(s, 0.4, y_base, 1.3, 0.4, label, sz=12, bold=False, color=TEXT_DARK)
        for i, cell in enumerate(cells):
            x = start_x + i * (col_w + gap)
            _mt(s, x, y_base + 0.1, col_w, 2.0, cell, sz=10, color=TEXT_DARK)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "1", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("input/default_input.pptx")
    print("  ✓ Input: input/default_input.pptx (plain text grid)")


# ═══════════════════════════════════════════════════════════
#  TEMPLATE 1: Header Bars + Sidebar (Page 2 style)
#  Green bars behind headers, icon circles, dark sidebar
# ═══════════════════════════════════════════════════════════

def create_t1():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH
    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    # Title + divider
    _t(s, 0.5, 0.25, 5, 0.45, "{title}", sz=20, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.7, 12.3, 0.03, ACCENT)

    # Icon circles above headers
    col_w = 2.1; start_x = 2.3; gap = 0.35
    for i in range(5):
        x = start_x + i * (col_w + gap)
        cx = x + col_w / 2 - 0.35
        # Icon circle with border
        _o(s, cx, 0.95, 0.7, BG_WHITE, border=PRIMARY)
        _t(s, cx, 1.0, 0.7, 0.6, f"{{icon_{i+1}}}",
           sz=9, color=PRIMARY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # Green header bars
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _r(s, x, 1.85, col_w, 0.45, PRIMARY)
        _t(s, x, 1.87, col_w, 0.4, f"{{header_{i+1}}}",
           sz=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # Dark sidebar for row labels
    _r(s, 0.0, 2.5, 1.8, 4.2, DARK_GREEN)

    # Row 1
    _t(s, 0.15, 2.65, 1.5, 0.5, "{row1_label}",
       sz=13, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _r(s, 0.15, 3.15, 1.0, 0.03, WHITE)
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 2.5, col_w, 2.0, f"{{row1_col{i+1}}}",
           sz=9, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    # Dashed divider line (simulated with thin light rect)
    _r(s, 2.3, 4.55, 10.5, 0.01, BORDER)

    # Row 2
    _t(s, 0.15, 4.75, 1.5, 0.5, "{row2_label}",
       sz=13, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 4.7, col_w, 2.0, f"{{row2_col{i+1}}}",
           sz=9, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "{page}", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("templates/template_header_sidebar.pptx")
    print("  ✓ T1: Header Bars + Sidebar")


# ═══════════════════════════════════════════════════════════
#  TEMPLATE 2: Tall Separate Cards (Page 3 style)
#  5 tall cards, dark green top with icon, white body, green bottom
# ═══════════════════════════════════════════════════════════

def create_t2():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH
    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    _t(s, 0.5, 0.25, 5, 0.45, "{title}", sz=20, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.7, 12.3, 0.03, ACCENT)

    col_w = 2.3; start_x = 0.65; gap = 0.28
    card_h = 5.8; card_top = 1.0
    green_h = 1.6

    for i in range(5):
        x = start_x + i * (col_w + gap)

        # Card body (white with light border)
        _rr(s, x, card_top, col_w, card_h, BG_WHITE, border=BORDER)

        # Green top section
        _r(s, x + 0.02, card_top + 0.02, col_w - 0.04, green_h, PRIMARY)

        # Diagonal cut (simulated with white triangle-ish shape)
        # We use a simple approach: white rect at bottom-right of green area
        _r(s, x + col_w * 0.55, card_top + green_h - 0.35, col_w * 0.44, 0.37, BG_WHITE)

        # Icon circle in green area
        cx = x + col_w / 2 - 0.4
        _o(s, cx, card_top + 0.25, 0.8, BG_WHITE, border=PRIMARY_LT)
        _t(s, cx, card_top + 0.3, 0.8, 0.7, f"{{icon_{i+1}}}",
           sz=9, color=PRIMARY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

        # Header text below green
        _t(s, x + 0.1, card_top + green_h + 0.15, col_w - 0.2, 0.5,
           f"{{header_{i+1}}}", sz=12, bold=True, color=TEXT_DARK,
           align=PP_ALIGN.CENTER)
        _r(s, x + 0.3, card_top + green_h + 0.7, col_w - 0.6, 0.02, ACCENT)

        # Row 1 label + content
        _t(s, x + 0.1, card_top + green_h + 0.85, col_w - 0.2, 0.2,
           "{row1_label}", sz=7, bold=True, color=PRIMARY)
        _t(s, x + 0.1, card_top + green_h + 1.05, col_w - 0.2, 1.5,
           f"{{row1_col{i+1}}}", sz=8, color=TEXT_DARK, align=PP_ALIGN.CENTER)

        # Divider
        _r(s, x + 0.2, card_top + green_h + 2.6, col_w - 0.4, 0.01, BORDER)

        # Row 2 label + content
        _t(s, x + 0.1, card_top + green_h + 2.75, col_w - 0.2, 0.2,
           "{row2_label}", sz=7, bold=True, color=PRIMARY)
        _t(s, x + 0.1, card_top + green_h + 2.95, col_w - 0.2, 1.0,
           f"{{row2_col{i+1}}}", sz=8, color=TEXT_MID, align=PP_ALIGN.CENTER)

        # Green bottom bar
        _r(s, x + 0.02, card_top + card_h - 0.22, col_w - 0.04, 0.2, PRIMARY)

    # Row labels on left side
    _t(s, 0.05, 3.5, 0.55, 0.3, "{row1_label}", sz=9, color=TEXT_DARK)
    _t(s, 0.05, 5.5, 0.55, 0.3, "{row2_label}", sz=9, color=TEXT_DARK)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "{page}", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("templates/template_tall_cards.pptx")
    print("  ✓ T2: Tall Separate Cards")


# ═══════════════════════════════════════════════════════════
#  TEMPLATE 3: Icon + Header Bar + Bordered Cards (Page 4)
#  Icons above green bars, content in bordered areas, badge labels
# ═══════════════════════════════════════════════════════════

def create_t3():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH
    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    _t(s, 0.5, 0.25, 5, 0.45, "{title}", sz=20, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.7, 12.3, 0.03, ACCENT)

    col_w = 2.15; start_x = 2.0; gap = 0.3

    # Icon circles
    for i in range(5):
        x = start_x + i * (col_w + gap)
        cx = x + col_w / 2 - 0.3
        _o(s, cx, 0.9, 0.6, PRIMARY)
        _t(s, cx, 0.93, 0.6, 0.55, f"{{icon_{i+1}}}",
           sz=8, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # Green header bars with dotted bottom border
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _r(s, x, 1.7, col_w, 0.45, PRIMARY)
        _t(s, x, 1.72, col_w, 0.4, f"{{header_{i+1}}}",
           sz=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        _r(s, x, 2.15, col_w, 0.02, ACCENT)

    # Row 1 — badge label on left
    badge_w = 1.5
    _rr(s, 0.15, 2.5, badge_w, 0.8, PRIMARY)
    _t(s, 0.15, 2.55, badge_w, 0.7, "{row1_label}",
       sz=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 2.4, col_w, 2.0, f"{{row1_col{i+1}}}",
           sz=9, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    # Divider line
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _r(s, x + 0.2, 4.5, col_w - 0.4, 0.01, BORDER)

    # Row 2 — badge label
    _rr(s, 0.15, 4.75, badge_w, 0.8, PRIMARY)
    _t(s, 0.15, 4.8, badge_w, 0.7, "{row2_label}",
       sz=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 4.65, col_w, 2.0, f"{{row2_col{i+1}}}",
           sz=9, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "{page}", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("templates/template_icon_bordered.pptx")
    print("  ✓ T3: Icon + Bordered Cards")


# ═══════════════════════════════════════════════════════════
#  TEMPLATE 4: Rounded Cards with Numbers (Page 5 style)
#  Tall rounded cards, icon at top, content in middle, large numbers
# ═══════════════════════════════════════════════════════════

def create_t4():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH
    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    _t(s, 0.5, 0.25, 5, 0.45, "{title}", sz=20, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.7, 12.3, 0.03, ACCENT)

    col_w = 2.35; start_x = 0.55; gap = 0.22
    card_h = 6.0; card_top = 0.95
    green_h = 1.4

    for i in range(5):
        x = start_x + i * (col_w + gap)

        # Card with rounded corners (light bg)
        _rr(s, x, card_top, col_w, card_h, BG_LIGHT, border=BORDER)

        # Dark green top area
        _r(s, x + 0.02, card_top + 0.02, col_w - 0.04, green_h, PRIMARY)

        # Icon inside green area
        cx = x + col_w / 2 - 0.35
        _o(s, cx, card_top + 0.2, 0.7, BG_WHITE, border=PRIMARY_LT)
        _t(s, cx, card_top + 0.24, 0.7, 0.62, f"{{icon_{i+1}}}",
           sz=9, color=PRIMARY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

        # Header
        _t(s, x + 0.1, card_top + green_h + 0.15, col_w - 0.2, 0.5,
           f"{{header_{i+1}}}", sz=11, bold=True, color=TEXT_DARK,
           align=PP_ALIGN.CENTER)
        _r(s, x + 0.3, card_top + green_h + 0.7, col_w - 0.6, 0.02, ACCENT)

        # Row 1 content
        _t(s, x + 0.1, card_top + green_h + 0.85, col_w - 0.2, 1.5,
           f"{{row1_col{i+1}}}", sz=8, color=TEXT_DARK, align=PP_ALIGN.CENTER)

        # Row divider
        _r(s, x + 0.2, card_top + green_h + 2.45, col_w - 0.4, 0.01, BORDER)

        # Row 2 content
        _t(s, x + 0.1, card_top + green_h + 2.6, col_w - 0.2, 1.0,
           f"{{row2_col{i+1}}}", sz=8, color=TEXT_MID, align=PP_ALIGN.CENTER)

        # Large number at bottom
        _t(s, x, card_top + card_h - 1.1, col_w, 0.9,
           str(i + 1), sz=48, bold=True, color=BORDER,
           align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # Row labels on left
    _t(s, 0.0, 3.3, 0.5, 0.3, "{row1_label}", sz=8, color=TEXT_DARK)
    _t(s, 0.0, 5.2, 0.5, 0.3, "{row2_label}", sz=8, color=TEXT_DARK)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "{page}", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("templates/template_numbered_cards.pptx")
    print("  ✓ T4: Rounded Cards with Numbers")


# ═══════════════════════════════════════════════════════════
#  TEMPLATE 5: Minimal Clean Grid (Page 1 style — baseline)
#  Just clean text with subtle borders, no heavy graphics
# ═══════════════════════════════════════════════════════════

def create_t5():
    prs = Presentation(); prs.slide_width = SW; prs.slide_height = SH
    s = prs.slides.add_slide(prs.slide_layouts[6]); _bg(s, BG_WHITE)

    _t(s, 0.5, 0.25, 5, 0.45, "{title}", sz=20, bold=True, color=PRIMARY, font=FONT_H)
    _r(s, 0.5, 0.7, 12.3, 0.03, ACCENT)

    col_w = 2.2; start_x = 2.0; gap = 0.25

    # Column headers
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 1.2, col_w, 0.5, f"{{header_{i+1}}}",
           sz=14, bold=True, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    # Thin line under headers
    _r(s, 2.0, 1.75, 10.5, 0.02, BORDER)

    # Row 1
    _t(s, 0.4, 2.1, 1.3, 0.3, "{row1_label}", sz=12, color=TEXT_DARK)
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 2.1, col_w, 2.0, f"{{row1_col{i+1}}}",
           sz=10, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    # Row 2
    _t(s, 0.4, 4.6, 1.3, 0.3, "{row2_label}", sz=12, color=TEXT_DARK)
    for i in range(5):
        x = start_x + i * (col_w + gap)
        _t(s, x, 4.6, col_w, 2.0, f"{{row2_col{i+1}}}",
           sz=10, color=TEXT_DARK, align=PP_ALIGN.CENTER)

    _footer_bar(s, FOOTER_L, FOOTER_R)
    _t(s, 12.5, 7.1, 0.5, 0.3, "{page}", sz=9, color=TEXT_LIGHT, align=PP_ALIGN.RIGHT)

    prs.save("templates/template_minimal_grid.pptx")
    print("  ✓ T5: Minimal Clean Grid")


# ═══════════════════════════════════════════════════════════
def main():
    print("\n╔══════════════════════════════════════════════════╗")
    print("║  EZ Works — Sample File Generator                ║")
    print("╚══════════════════════════════════════════════════╝\n")

    print("Generating input (plain text grid)...")
    create_input()

    print("\nGenerating 5 visual templates...")
    create_t1()
    create_t2()
    create_t3()
    create_t4()
    create_t5()

    print(f"\n✅ Done!")
    print(f"   Input:  Plain 5×2 text grid (simple)")
    print(f"   T1: Header bars + dark sidebar + icon circles")
    print(f"   T2: Tall separate cards with green top + white body")
    print(f"   T3: Icon circles + green header bars + badge labels")
    print(f"   T4: Rounded cards with icons + large numbers at bottom")
    print(f"   T5: Minimal clean text grid (baseline)\n")


if __name__ == "__main__":
    main()