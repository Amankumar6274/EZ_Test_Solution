"""
src/logger.py
=============
Centralized logging configuration.
Logs to both console (INFO+) and file (DEBUG+).
Log file: output/pipeline.log
"""

import os
import logging
import sys
from datetime import datetime


LOG_DIR = "output"
LOG_FILE = os.path.join(LOG_DIR, "pipeline.log")

_logger = None


def get_logger(name="ez_pptx"):
    """
    Get or create the application logger.
    First call initializes handlers; subsequent calls return the same logger.
    """
    global _logger
    if _logger is not None:
        return _logger

    os.makedirs(LOG_DIR, exist_ok=True)

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Prevent duplicate handlers on reimport
    if logger.handlers:
        _logger = logger
        return _logger

    # ── File handler (DEBUG level — captures everything) ────────
    fh = logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    file_fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(module)-20s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    fh.setFormatter(file_fmt)
    logger.addHandler(fh)

    # ── Console handler (INFO level — user-facing output) ───────
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    console_fmt = logging.Formatter("  %(message)s")
    ch.setFormatter(console_fmt)
    logger.addHandler(ch)

    # Write header to log file
    logger.debug("=" * 70)
    logger.debug(f"EZ Works PPTX Pipeline — Log started {datetime.now().isoformat()}")
    logger.debug(f"Python {sys.version}")
    logger.debug("=" * 70)

    _logger = logger
    return _logger


def log_section(title):
    """Log a major section divider."""
    logger = get_logger()
    border = "=" * 60
    logger.info("")
    logger.info(border)
    logger.info(f"  {title}")
    logger.info(border)
    logger.debug(f"[SECTION] {title}")


def log_subsection(title):
    """Log a minor subsection."""
    logger = get_logger()
    logger.info(f"  ── {title} ──")
    logger.debug(f"[SUBSECTION] {title}")


def log_result(key, value):
    """Log a key-value result."""
    logger = get_logger()
    logger.info(f"  {key}: {value}")
    logger.debug(f"[RESULT] {key} = {value}")


def log_table(headers, rows, col_widths=None):
    """Log a formatted table to both console and file."""
    logger = get_logger()
    if not col_widths:
        col_widths = [max(len(str(h)), max((len(str(r[i])) for r in rows), default=4)) + 2
                      for i, h in enumerate(headers)]

    header_line = "│".join(str(h).center(w) for h, w in zip(headers, col_widths))
    sep_line = "┼".join("─" * w for w in col_widths)

    logger.info(f"  ┌{'┬'.join('─' * w for w in col_widths)}┐")
    logger.info(f"  │{header_line}│")
    logger.info(f"  ├{sep_line}┤")
    for row in rows:
        row_line = "│".join(str(v).center(w) for v, w in zip(row, col_widths))
        logger.info(f"  │{row_line}│")
    logger.info(f"  └{'┴'.join('─' * w for w in col_widths)}┘")