
"""
src/generator.py
================
Slot-fill generator: opens the selected template PPTX,
finds all placeholder text patterns like {header_1}, {row1_col3},
and replaces them with extracted content from the input.

All template visuals (shapes, colors, icons, cards) are preserved.
Only the placeholder text is swapped with real data.
"""

import os
import re
from copy import deepcopy
from pptx import Presentation
from pptx.util import Inches, Pt

from src.logger import get_logger


class PresentationGenerator:
    """
    Opens a template PPTX, scans every text frame for {placeholder} patterns,
    and replaces them with extracted content.
    """

    def __init__(self, extracted_content, selected_template_analysis,
                 template_path, embedding_manager=None, slide_assignments=None):
        self.content = extracted_content
        self.tmpl_analysis = selected_template_analysis
        self.template_path = template_path
        self.slide_assignments = slide_assignments or []
        self.log = get_logger()

    def generate(self, output_path="output/final_presentation.pptx"):
        self.log.info(f"Generating from template: {self.template_path}")

        # Build the replacement map from extracted content
        replacements = self._build_replacement_map()
        self.log.info(f"  Built {len(replacements)} replacements")
        for k, v in list(replacements.items())[:10]:
            self.log.debug(f"    {k} → {v[:50]}..." if len(v) > 50 else f"    {k} → {v}")

        # Open template and fill slots
        prs = Presentation(self.template_path)

        filled = 0
        unfilled = []

        for slide in prs.slides:
            for shape in slide.shapes:
                # Text frames (textboxes, autoshapes with text)
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        full_text = para.text
                        if "{" in full_text and "}" in full_text:
                            new_text = self._replace_placeholders(full_text, replacements)
                            if new_text != full_text:
                                self._set_paragraph_text(para, new_text)
                                filled += 1
                            elif re.search(r'\{[a-z_0-9]+\}', full_text):
                                unfilled.append(full_text.strip())

                # Table cells
                if shape.has_table:
                    for row in shape.table.rows:
                        for col_idx in range(len(shape.table.columns)):
                            cell = shape.table.cell(row.row_idx if hasattr(row, 'row_idx') else 0, col_idx)
                            for para in cell.text_frame.paragraphs:
                                full_text = para.text
                                if "{" in full_text and "}" in full_text:
                                    new_text = self._replace_placeholders(full_text, replacements)
                                    if new_text != full_text:
                                        self._set_paragraph_text(para, new_text)
                                        filled += 1

        self.log.info(f"  ✓ Filled {filled} placeholder slots")
        if unfilled:
            self.log.info(f"  ⚠ {len(unfilled)} unfilled placeholders remain:")
            for uf in unfilled[:5]:
                self.log.debug(f"    {uf}")

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        prs.save(output_path)
        self.log.info(f"  ✓ Saved: {output_path}")
        return output_path

    def _build_replacement_map(self):
        """
        Build a dict of {placeholder_key: content_value} from extracted data.

        Expected placeholders in templates:
          {title}          → slide title
          {header_1}..{header_5} → column headers
          {row1_label}     → "Point 1" etc.
          {row2_label}     → "Point 2" etc.
          {row1_col1}..{row1_col5} → row 1 cell content
          {row2_col1}..{row2_col5} → row 2 cell content
          {icon_1}..{icon_5}       → icon labels (short)
          {page}           → page number
          {description}    → body text
        """
        rmap = {}
        slides = self.content.get("slides", [])

        if not slides:
            return rmap

        slide = slides[0]
        blocks = slide.get("text_blocks", [])
        tables = slide.get("tables", [])
        grid = slide.get("grid", {})

        # ── BEST PATH: Use detected grid structure ──────────
        if grid and grid.get("detected"):
            self.log.info(f"  Using detected grid: {grid['n_columns']} cols × {grid['n_data_rows']} rows")

            headers = grid.get("headers", [])
            data_rows = grid.get("data_rows", [])
            row_labels = grid.get("row_labels", [])

            for i, h in enumerate(headers):
                rmap[f"header_{i+1}"] = h.strip()
                words = h.replace("\n", " ").strip().split()
                rmap[f"icon_{i+1}"] = words[0][:8] if words else str(i + 1)

            for r_idx, row_data in enumerate(data_rows):
                for c_idx, cell_text in enumerate(row_data):
                    rmap[f"row{r_idx+1}_col{c_idx+1}"] = cell_text.strip()

            for i, lbl in enumerate(row_labels):
                rmap[f"row{i+1}_label"] = lbl.strip()

            rmap.setdefault("row1_label", row_labels[0] if row_labels else "Point 1")
            rmap.setdefault("row2_label", row_labels[1] if len(row_labels) > 1 else "Point 2")

        # ── FALLBACK: Use table data ────────────────────────
        elif tables:
            td = tables[0].get("table_data", {})
            headers = td.get("header_row", [])
            data_rows = td.get("data_rows", [])

            for i, h in enumerate(headers):
                rmap[f"header_{i+1}"] = h.strip()
                # Short icon text from first word of header
                words = h.replace("\n", " ").strip().split()
                rmap[f"icon_{i+1}"] = words[0][:6] if words else str(i+1)

            for r_idx, row_data in enumerate(data_rows):
                for c_idx, cell_text in enumerate(row_data):
                    rmap[f"row{r_idx+1}_col{c_idx+1}"] = cell_text.strip()

            rmap["row1_label"] = "Point 1"
            rmap["row2_label"] = "Point 2"

        # ── Extract from text blocks (non-table input) ──────
        else:
            # Try to detect grid structure from positions
            # Group blocks by y-position into rows
            content_blocks = [b for b in blocks
                              if b.get("semantic_role") not in ("title", "footer", "caption")]

            if content_blocks:
                # Sort by position
                sorted_by_y = sorted(content_blocks, key=lambda b: b.get("shape_position", {}).get("y", 0))

                # Detect rows by y-clustering
                rows = []
                current_row = [sorted_by_y[0]]
                for b in sorted_by_y[1:]:
                    prev_y = current_row[-1].get("shape_position", {}).get("y", 0)
                    curr_y = b.get("shape_position", {}).get("y", 0)
                    if abs(curr_y - prev_y) < 0.08:
                        current_row.append(b)
                    else:
                        rows.append(sorted(current_row, key=lambda b: b.get("shape_position", {}).get("x", 0)))
                        current_row = [b]
                rows.append(sorted(current_row, key=lambda b: b.get("shape_position", {}).get("x", 0)))

                # First row with multiple items = headers
                for r_idx, row in enumerate(rows):
                    if len(row) >= 3 and r_idx == 0:
                        for c_idx, b in enumerate(row):
                            rmap[f"header_{c_idx+1}"] = b["text"].strip()
                            words = b["text"].replace("\n", " ").strip().split()
                            rmap[f"icon_{c_idx+1}"] = words[0][:6] if words else str(c_idx+1)
                    elif len(row) >= 3:
                        data_row_idx = r_idx  # row1, row2, etc.
                        for c_idx, b in enumerate(row):
                            rmap[f"row{data_row_idx}_col{c_idx+1}"] = b["text"].strip()
                    elif len(row) == 1:
                        # Likely a row label
                        text = row[0]["text"].strip()
                        if "point" in text.lower() or text in ("Point 1", "Point 2"):
                            pass  # already handled

                rmap.setdefault("row1_label", "Point 1")
                rmap.setdefault("row2_label", "Point 2")

        # ── Title ───────────────────────────────────────────
        title_blocks = [b for b in blocks if b.get("semantic_role") == "title"]
        if title_blocks:
            rmap["title"] = title_blocks[0]["text"].strip()
        else:
            # Check all slides for a title
            for s in slides:
                for b in s.get("text_blocks", []):
                    if b.get("semantic_role") == "title":
                        rmap["title"] = b["text"].strip()
                        break
                if "title" in rmap:
                    break
        rmap.setdefault("title", "Content Overview")

        # ── Description / body ──────────────────────────────
        body_blocks = [b for b in blocks if b.get("semantic_role") in ("body", "bullet_list", "subtitle")]
        if body_blocks:
            rmap["description"] = body_blocks[0]["text"].strip()
        rmap.setdefault("description", "")

        # ── Page number ─────────────────────────────────────
        rmap["page"] = "1"

        # ── Defaults for missing slots ──────────────────────
        for i in range(1, 6):
            rmap.setdefault(f"header_{i}", f"Column {i}")
            rmap.setdefault(f"icon_{i}", str(i))
            rmap.setdefault(f"row1_col{i}", "")
            rmap.setdefault(f"row2_col{i}", "")
        rmap.setdefault("row1_label", "Point 1")
        rmap.setdefault("row2_label", "Point 2")

        return rmap

    def generate_all_preview(self, all_template_paths, scores,
                             output_path="output/all_templates_preview.pptx"):
        """
        Generate a single PPTX with content filled into ALL templates.
        
        Strategy: Build the preview by creating a fresh presentation,
        adding divider slides and then for each template, creating
        filled slides from scratch (not copying — avoids broken images).
        """
        self.log.info(f"Generating all-templates preview...")

        replacements = self._build_replacement_map()
        import tempfile

        # Step 1: Fill each template and save to temp files
        temp_files = []
        for rank, score_entry in enumerate(scores):
            tmpl_name = score_entry["template_name"]
            tmpl_path = score_entry["template_path"]
            total_score = score_entry["total_score"]

            self.log.info(f"  #{rank+1} {tmpl_name} (score={total_score:.3f})")

            try:
                tmpl_prs = Presentation(tmpl_path)
                for slide in tmpl_prs.slides:
                    for shape in slide.shapes:
                        if shape.has_text_frame:
                            for para in shape.text_frame.paragraphs:
                                full_text = para.text
                                if "{" in full_text and "}" in full_text:
                                    new_text = self._replace_placeholders(full_text, replacements)
                                    if new_text != full_text:
                                        self._set_paragraph_text(para, new_text)

                tmp = tempfile.NamedTemporaryFile(suffix=".pptx", delete=False)
                tmpl_prs.save(tmp.name)
                temp_files.append((rank, tmpl_name, total_score, tmp.name))
                tmp.close()
            except Exception as e:
                self.log.warning(f"  ⚠ Failed to process {tmpl_name}: {e}")
                continue

        # Step 2: Merge all temp files into one PPTX
        # We use the first template as the base and append others
        if not temp_files:
            self.log.warning("  No templates processed for preview")
            return output_path

        merged_prs = Presentation()
        merged_prs.slide_width = Inches(13.333)
        merged_prs.slide_height = Inches(7.5)

        for rank, tmpl_name, total_score, tmp_path in temp_files:
            # Add divider slide
            self._add_divider_slide(merged_prs, rank + 1, tmpl_name, total_score)

            # Open the filled temp file and copy slides properly
            try:
                filled_prs = Presentation(tmp_path)
                for slide in filled_prs.slides:
                    # Create new blank slide
                    new_slide = merged_prs.slides.add_slide(merged_prs.slide_layouts[6])

                    # Copy background
                    try:
                        if slide.background.fill.type is not None:
                            new_slide.background.fill.solid()
                            new_slide.background.fill.fore_color.rgb = slide.background.fill.fore_color.rgb
                    except Exception:
                        pass

                    # Copy each shape properly based on type
                    for shape in slide.shapes:
                        self._copy_shape_to_slide(shape, new_slide, filled_prs, merged_prs)

            except Exception as e:
                self.log.warning(f"  ⚠ Failed to merge {tmpl_name}: {e}")

            # Cleanup temp file
            try:
                os.unlink(tmp_path)
            except Exception:
                pass

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        merged_prs.save(output_path)
        self.log.info(f"  ✓ All-templates preview saved: {output_path}")
        return output_path

    def _copy_shape_to_slide(self, shape, target_slide, source_prs, target_prs):
        """
        Copy a shape from one presentation to another, handling images properly.
        """
        from copy import deepcopy
        from pptx.enum.shapes import MSO_SHAPE_TYPE

        try:
            # For pictures: re-add the image properly
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                try:
                    image = shape.image
                    img_bytes = image.blob
                    content_type = image.content_type

                    # Save to temp and re-add
                    import tempfile
                    ext = {
                        "image/png": ".png",
                        "image/jpeg": ".jpg",
                        "image/gif": ".gif",
                        "image/svg+xml": ".svg",
                    }.get(content_type, ".png")

                    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                        tmp.write(img_bytes)
                        tmp_path = tmp.name

                    target_slide.shapes.add_picture(
                        tmp_path, shape.left, shape.top, shape.width, shape.height
                    )
                    os.unlink(tmp_path)
                    return
                except Exception:
                    pass  # Fall through to XML copy

            # For tables: deepcopy the XML element
            if shape.has_table:
                el = deepcopy(shape._element)
                target_slide.shapes._spTree.insert_element_before(el, 'p:extLst')
                return

            # For all other shapes: deepcopy XML (works for rects, textboxes, ovals, etc.)
            el = deepcopy(shape._element)
            target_slide.shapes._spTree.insert_element_before(el, 'p:extLst')

        except Exception as e:
            self.log.debug(f"    Shape copy failed ({shape.name}): {e}")

    def _add_divider_slide(self, prs, rank, template_name, score):
        """Add a divider/separator slide between templates in the preview."""
        from pptx.dml.color import RGBColor
        from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

        slide = prs.slides.add_slide(prs.slide_layouts[6])

        # Dark background
        bg = slide.background.fill
        bg.solid()
        bg.fore_color.rgb = RGBColor(0x1B, 0x5E, 0x20)

        # Rank number
        tb = slide.shapes.add_textbox(Inches(2), Inches(1.5), Inches(9.3), Inches(1.2))
        tf = tb.text_frame; tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.text = f"Template #{rank}"
        p.alignment = PP_ALIGN.CENTER
        p.font.name = "Calibri Light"
        p.font.size = Pt(48)
        p.font.bold = True
        p.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        # Template name
        tb2 = slide.shapes.add_textbox(Inches(2), Inches(3.0), Inches(9.3), Inches(0.8))
        tf2 = tb2.text_frame; tf2.word_wrap = True
        p2 = tf2.paragraphs[0]
        p2.text = template_name.replace("template_", "").replace("_", " ").title()
        p2.alignment = PP_ALIGN.CENTER
        p2.font.name = "Calibri"
        p2.font.size = Pt(28)
        p2.font.color.rgb = RGBColor(0xC8, 0xA2, 0x2C)

        # Score
        tb3 = slide.shapes.add_textbox(Inches(3), Inches(4.2), Inches(7.3), Inches(0.6))
        tf3 = tb3.text_frame; tf3.word_wrap = True
        p3 = tf3.paragraphs[0]
        star = " ★ BEST MATCH" if rank == 1 else ""
        p3.text = f"Match Score: {score:.3f}{star}"
        p3.alignment = PP_ALIGN.CENTER
        p3.font.name = "Calibri"
        p3.font.size = Pt(18)
        p3.font.color.rgb = RGBColor(0xE8, 0xF5, 0xE9)

        # Accent line
        from pptx.enum.shapes import MSO_SHAPE
        line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(5.5), Inches(3.9), Inches(2.3), Inches(0.04)
        )
        line.fill.solid()
        line.fill.fore_color.rgb = RGBColor(0xC8, 0xA2, 0x2C)
        line.line.fill.background()

    def _replace_placeholders(self, text, replacements):
        """Replace all {key} patterns in text with values from replacements."""
        def _sub(match):
            key = match.group(1)
            return replacements.get(key, match.group(0))
        return re.sub(r'\{([a-z_0-9]+)\}', _sub, text)

    def _set_paragraph_text(self, para, new_text):
        """
        Replace paragraph text while preserving the first run's formatting.
        Handles multi-line text by replacing \n with line breaks.
        """
        if not para.runs:
            para.text = new_text
            return

        # Save formatting from the first run
        first_run = para.runs[0]
        font_name = first_run.font.name
        font_size = first_run.font.size
        font_bold = first_run.font.bold
        font_italic = first_run.font.italic
        try:
            font_color = first_run.font.color.rgb
        except Exception:
            font_color = None

        # Clear all existing runs
        for run in para.runs[1:]:
            run._r.getparent().remove(run._r)

        # Set the new text on the first run
        # Handle newlines by keeping them as-is (pptx renders \n as line breaks within a paragraph)
        first_run.text = new_text.replace("\n", "\n")

        # Restore formatting
        if font_name:
            first_run.font.name = font_name
        if font_size:
            first_run.font.size = font_size
        if font_bold is not None:
            first_run.font.bold = font_bold
        if font_italic is not None:
            first_run.font.italic = font_italic
        if font_color:
            try:
                first_run.font.color.rgb = font_color
            except Exception:
                pass