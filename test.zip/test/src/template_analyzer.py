"""
src/template_analyzer.py
========================
Module 2: Analyze candidate PPTX templates.
"""

import json
import os
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

from src.logger import get_logger
from src.utils import (
    emu_to_inches, normalize_position, safe_font_color,
    safe_font_size, detect_column_pattern, rgb_to_tuple, EmbeddingManager
)


class TemplateAnalyzer:

    def __init__(self, pptx_path, embedding_manager=None):
        self.pptx_path = pptx_path
        self.name = os.path.splitext(os.path.basename(pptx_path))[0]
        self.prs = Presentation(pptx_path)
        self.slide_w = self.prs.slide_width
        self.slide_h = self.prs.slide_height
        self.emb = embedding_manager or EmbeddingManager()
        self.analysis = {}
        self.log = get_logger()

    def analyze(self):
        self.log.debug(f"Analyzing template: {self.name}")
        self.analysis = {
            "template_name": self.name,
            "template_path": self.pptx_path,
            "slide_dimensions": {
                "width_inches": emu_to_inches(self.slide_w),
                "height_inches": emu_to_inches(self.slide_h),
                "width_emu": int(self.slide_w),
                "height_emu": int(self.slide_h),
            },
            "slide_layouts": self._analyze_layouts(),
            "slides": self._analyze_slides(),
            "color_scheme": self._extract_color_scheme(),
            "font_theme": self._extract_font_theme(),
            "capability_profile": {},
        }
        self.analysis["capability_profile"] = self._build_capability_profile()
        return self.analysis

    def _analyze_layouts(self):
        layouts = []
        for idx, layout in enumerate(self.prs.slide_layouts):
            li = {"index": idx, "name": layout.name, "placeholders": []}
            for ph in layout.placeholders:
                try:
                    li["placeholders"].append({
                        "idx": ph.placeholder_format.idx,
                        "type": str(ph.placeholder_format.type) if ph.placeholder_format.type else None,
                        "name": ph.name,
                        "position": normalize_position(
                            ph.left, ph.top, ph.width, ph.height, self.slide_w, self.slide_h
                        ),
                    })
                except Exception:
                    pass
            layouts.append(li)
        self.log.debug(f"  Found {len(layouts)} slide layouts")
        return layouts

    def _analyze_slides(self):
        slides = []
        for s_idx, slide in enumerate(self.prs.slides):
            si = {
                "slide_number": s_idx + 1, "shapes": [], "text_zones": [],
                "shape_zones": [], "table_zones": [], "fingerprint": {},
            }
            for shape in slide.shapes:
                sd = self._analyze_shape(shape)
                si["shapes"].append(sd)
                if sd["has_text"]:
                    si["text_zones"].append({
                        "position": sd["position"], "text_content": sd.get("text", ""),
                        "font_size": sd.get("max_font_size"), "is_bold": sd.get("is_bold", False),
                        "type": sd["type"],
                    })
                if sd["type"] == "autoshape":
                    si["shape_zones"].append(sd)
                if sd["type"] == "table":
                    si["table_zones"].append(sd)
            si["fingerprint"] = self._slide_fingerprint(si)
            slides.append(si)
        return slides

    def _analyze_shape(self, shape):
        info = {
            "shape_id": shape.shape_id, "name": shape.name,
            "type": self._get_shape_type(shape),
            "position": normalize_position(
                shape.left, shape.top, shape.width, shape.height, self.slide_w, self.slide_h
            ),
            "size_inches": {"width": emu_to_inches(shape.width), "height": emu_to_inches(shape.height)},
            "has_text": shape.has_text_frame if hasattr(shape, "has_text_frame") else False,
            "is_placeholder": False,
        }
        if shape.is_placeholder:
            info["is_placeholder"] = True
            try:
                info["placeholder_idx"] = shape.placeholder_format.idx
                info["placeholder_type"] = str(shape.placeholder_format.type)
            except Exception:
                pass

        if info["has_text"] and shape.has_text_frame:
            info["text"] = shape.text_frame.text
            max_size, is_bold = 0, False
            font_names, colors = set(), []
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    sz = safe_font_size(run.font)
                    if sz and sz > max_size: max_size = sz
                    if run.font.bold: is_bold = True
                    if run.font.name: font_names.add(run.font.name)
                    clr = safe_font_color(run.font)
                    if clr: colors.append(clr)
            info["max_font_size"] = max_size if max_size > 0 else None
            info["is_bold"] = is_bold
            info["font_names"] = list(font_names)
            info["text_colors"] = colors

        try:
            if hasattr(shape, "fill") and shape.fill.type is not None:
                info["fill_type"] = str(shape.fill.type)
                try: info["fill_color"] = str(shape.fill.fore_color.rgb)
                except Exception: pass
        except Exception:
            pass

        if shape.has_table:
            info["type"] = "table"
            info["table_rows"] = len(shape.table.rows)
            info["table_cols"] = len(shape.table.columns)

        try:
            info["auto_shape_type"] = str(shape.auto_shape_type)
        except (ValueError, AttributeError):
            pass
        return info

    def _get_shape_type(self, shape):
        if shape.has_table: return "table"
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE: return "picture"
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP: return "group"
        if shape.shape_type == MSO_SHAPE_TYPE.CHART: return "chart"
        if shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE: return "autoshape"
        if hasattr(shape, "has_text_frame") and shape.has_text_frame: return "textbox"
        return "other"

    def _slide_fingerprint(self, slide_info):
        text_positions = [tz["position"] for tz in slide_info["text_zones"]]
        col_count = detect_column_pattern(text_positions)
        has_table = len(slide_info["table_zones"]) > 0
        text_count = len(slide_info["text_zones"])
        shape_count = len([s for s in slide_info["shapes"] if s["type"] == "autoshape"])

        if text_count <= 3 and any(
            tz.get("font_size") and tz["font_size"] > 30 for tz in slide_info["text_zones"]
        ):
            layout_type = "title_slide"
        elif has_table:
            layout_type = "table_layout"
        elif col_count >= 4:
            layout_type = "multi_column"
        elif col_count == 2:
            layout_type = "two_column"
        elif col_count == 3:
            layout_type = "three_column"
        else:
            layout_type = "full_width"

        return {
            "layout_type": layout_type, "column_count": col_count,
            "text_zone_count": text_count, "shape_zone_count": shape_count,
            "has_table": has_table, "has_decorative_shapes": shape_count > text_count,
            "content_density": "high" if text_count > 10 else "medium" if text_count > 5 else "low",
        }

    def _extract_color_scheme(self):
        colors = {"backgrounds": [], "text": [], "accents": [], "fills": []}
        for slide in self.prs.slides:
            try:
                bg = slide.background
                if bg.fill and bg.fill.type is not None:
                    try: colors["backgrounds"].append(str(bg.fill.fore_color.rgb))
                    except Exception: pass
            except Exception: pass
            for shape in slide.shapes:
                try:
                    if hasattr(shape, "fill") and shape.fill.type is not None:
                        try: colors["fills"].append(str(shape.fill.fore_color.rgb))
                        except Exception: pass
                except Exception: pass
                if hasattr(shape, "has_text_frame") and shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        for run in para.runs:
                            clr = safe_font_color(run.font)
                            if clr and isinstance(clr, tuple) and len(clr) == 3:
                                colors["text"].append(f"{clr[0]:02X}{clr[1]:02X}{clr[2]:02X}")
        for k in colors: colors[k] = list(set(colors[k]))
        return colors

    def _extract_font_theme(self):
        fonts = {"heading_fonts": set(), "body_fonts": set(), "all_fonts": set()}
        for slide in self.prs.slides:
            for shape in slide.shapes:
                if not (hasattr(shape, "has_text_frame") and shape.has_text_frame): continue
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.name:
                            fonts["all_fonts"].add(run.font.name)
                            sz = safe_font_size(run.font)
                            if sz and sz >= 20: fonts["heading_fonts"].add(run.font.name)
                            else: fonts["body_fonts"].add(run.font.name)
        return {k: list(v) for k, v in fonts.items()}

    def _build_capability_profile(self):
        slides = self.analysis["slides"]
        layout_types = [s["fingerprint"]["layout_type"] for s in slides]
        max_cols = max((s["fingerprint"]["column_count"] for s in slides), default=1)
        has_any_table = any(s["fingerprint"]["has_table"] for s in slides)
        layout_variety = len(set(layout_types))
        return {
            "supported_layouts": list(set(layout_types)),
            "max_column_support": max_cols,
            "has_title_slide": "title_slide" in layout_types,
            "has_multi_column": "multi_column" in layout_types,
            "has_table_layout": has_any_table,
            "has_full_width": "full_width" in layout_types,
            "has_two_column": "two_column" in layout_types,
            "layout_variety_score": layout_variety / max(len(slides), 1),
            "total_slides": len(slides),
            "total_text_zones": sum(s["fingerprint"]["text_zone_count"] for s in slides),
            "avg_shapes_per_slide": sum(len(s["shapes"]) for s in slides) / max(len(slides), 1),
        }


def analyze_all_templates(template_dir="templates", embedding_manager=None):
    log = get_logger()
    results = []
    emb = embedding_manager or EmbeddingManager()
    pptx_files = sorted([
        f for f in os.listdir(template_dir)
        if f.endswith(".pptx") and not f.startswith("~$")
    ])
    log.info(f"Found {len(pptx_files)} templates in {template_dir}/")

    for fname in pptx_files:
        path = os.path.join(template_dir, fname)
        log.info(f"Analyzing: {fname}")
        try:
            analyzer = TemplateAnalyzer(path, emb)
            result = analyzer.analyze()
            results.append(result)
            cap = result["capability_profile"]
            log.info(f"  Layouts: {cap['supported_layouts']}, Max cols: {cap['max_column_support']}")
            log.debug(f"  Full capability: {json.dumps(cap, indent=2)}")
        except Exception as e:
            log.warning(f"  ⚠ Skipping {fname}: {e}")
            continue
    return results


def save_template_analysis(analyses, output_path="output/template_analysis.json"):
    log = get_logger()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    def _clean(obj):
        if isinstance(obj, float): return round(obj, 6) if obj == obj else None
        if isinstance(obj, set): return list(obj)
        return obj
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(analyses, f, indent=2, ensure_ascii=False, default=_clean)
    log.info(f"✓ Template analysis saved to {output_path}")