
"""
src/extractor.py
================
Module 1: Deep content extraction from input PPTX.
"""

import json
import os
from pptx import Presentation
from pptx.util import Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE

from src.logger import get_logger
from src.utils import (
    emu_to_inches, emu_to_pt, normalize_position,
    safe_font_color, safe_font_size, classify_text_role,
    detect_column_pattern, EmbeddingManager, ROLE_DESCRIPTORS
)


class ContentExtractor:
    """Extracts all meaningful content and metadata from a PPTX file."""

    def __init__(self, pptx_path, embedding_manager=None):
        self.pptx_path = pptx_path
        self.prs = Presentation(pptx_path)
        self.slide_w = self.prs.slide_width
        self.slide_h = self.prs.slide_height
        self.emb = embedding_manager or EmbeddingManager()
        self.extracted_data = {"slides": [], "metadata": {}}
        self.log = get_logger()

    def extract(self):
        """Run full extraction pipeline."""
        self.log.info(f"Extracting from: {self.pptx_path}")
        self.log.debug(f"Slide dimensions: {emu_to_inches(self.slide_w):.2f}\" x {emu_to_inches(self.slide_h):.2f}\"")

        self.extracted_data["metadata"] = {
            "source_file": self.pptx_path,
            "slide_width_inches": emu_to_inches(self.slide_w),
            "slide_height_inches": emu_to_inches(self.slide_h),
            "slide_count": len(self.prs.slides),
            "slide_width_emu": int(self.slide_w),
            "slide_height_emu": int(self.slide_h),
        }

        for slide_idx, slide in enumerate(self.prs.slides):
            slide_data = self._extract_slide(slide, slide_idx)
            self.extracted_data["slides"].append(slide_data)
            self.log.debug(
                f"Slide {slide_idx+1}: {len(slide_data['shapes'])} shapes, "
                f"{len(slide_data['tables'])} tables, "
                f"{len(slide_data['text_blocks'])} text blocks"
            )

        self._add_semantic_embeddings()

        total_shapes = sum(len(s["shapes"]) for s in self.extracted_data["slides"])
        total_tables = sum(len(s["tables"]) for s in self.extracted_data["slides"])
        total_text = sum(len(s["text_blocks"]) for s in self.extracted_data["slides"])
        self.log.info(
            f"✓ Extracted {len(self.extracted_data['slides'])} slides, "
            f"{total_shapes} shapes, {total_tables} tables, {total_text} text blocks"
        )
        return self.extracted_data

    def _extract_slide(self, slide, slide_idx):
        slide_data = {
            "slide_number": slide_idx + 1,
            "shapes": [], "tables": [], "images": [], "text_blocks": [],
            "fingerprint": {},
        }
        for shape in slide.shapes:
            shape_info = self._extract_shape(shape)
            if shape_info:
                slide_data["shapes"].append(shape_info)
                if shape_info["type"] == "table":
                    slide_data["tables"].append(shape_info)
                elif shape_info["type"] == "picture":
                    slide_data["images"].append(shape_info)
                if shape_info.get("text_blocks"):
                    slide_data["text_blocks"].extend(shape_info["text_blocks"])
        slide_data["fingerprint"] = self._build_fingerprint(slide_data)

        # Second pass: detect grid structure and fix roles
        self._detect_grid_structure(slide_data)

        return slide_data

    def _detect_grid_structure(self, slide_data):
        """
        Second pass: detect grid patterns from text block positions.
        
        Strategy:
          1. Separate blocks into potential headers, row labels, and content cells
             using x-position (left-side labels vs right-side content)
          2. Group content blocks by y-position into rows
          3. First bold row in content area = headers
          4. Subsequent rows = data rows
          5. Left-side blocks near data rows = row labels
        """
        blocks = slide_data["text_blocks"]
        if len(blocks) < 5:
            return

        # Separate blocks into left-side (potential row labels) and right-side (content)
        LEFT_THRESHOLD = 0.13   # blocks with x < this are potential row labels
        HEADER_Y_MAX = 0.3      # headers must be above this
        CONTENT_Y_MIN = 0.12    # content starts below title area

        title_blocks = [b for b in blocks if b.get("semantic_role") == "title"]
        footer_blocks = [b for b in blocks if b.get("semantic_role") in ("footer", "caption")]

        left_blocks = []   # potential row labels
        right_blocks = []  # headers and content cells

        for b in blocks:
            if b in title_blocks or b in footer_blocks:
                continue
            pos = b.get("shape_position", {})
            x = pos.get("x", 0)
            y = pos.get("y", 0)
            w = pos.get("w", 0)

            if y < CONTENT_Y_MIN:
                continue  # skip title area

            if x < LEFT_THRESHOLD and w < 0.15:
                left_blocks.append(b)
            else:
                right_blocks.append(b)

        if len(right_blocks) < 5:
            return

        # Group right-side blocks by y-position
        from collections import defaultdict
        y_groups = defaultdict(list)
        for b in right_blocks:
            y = b.get("shape_position", {}).get("y", 0)
            y_key = round(y * 15) / 15  # cluster with ~0.067 threshold
            y_groups[y_key].append(b)

        # Find rows with 3+ blocks
        grid_rows = []
        for y_key in sorted(y_groups.keys()):
            row_blocks = y_groups[y_key]
            if len(row_blocks) >= 3:
                row_blocks.sort(key=lambda b: b.get("shape_position", {}).get("x", 0))
                grid_rows.append((y_key, row_blocks))

        if not grid_rows:
            return

        # First row = headers (bold, short text, near top)
        header_row = None
        data_rows = []

        for y_key, row_blocks in grid_rows:
            if header_row is None and y_key < HEADER_Y_MAX:
                # Check if this row looks like headers (bold and/or short text)
                is_header_like = any(
                    b.get("para_font", {}).get("bold") or
                    b.get("semantic_role") == "table_header"
                    for b in row_blocks
                )
                if is_header_like:
                    header_row = row_blocks
                    for b in header_row:
                        b["semantic_role"] = "table_header"
                        b["grid_role"] = "header"
                    continue

            # Everything else is a data row
            data_rows.append(row_blocks)
            for b in row_blocks:
                b["semantic_role"] = "content_cell"
                b["grid_role"] = f"data_row_{len(data_rows)}"

        if not header_row:
            # If no header detected, use the first row as header
            if grid_rows:
                _, header_row = grid_rows[0]
                for b in header_row:
                    b["semantic_role"] = "table_header"
                    b["grid_role"] = "header"
                data_rows = []
                for y_key, row_blocks in grid_rows[1:]:
                    data_rows.append(row_blocks)
                    for b in row_blocks:
                        b["semantic_role"] = "content_cell"
                        b["grid_role"] = f"data_row_{len(data_rows)}"

        # Match left-side blocks to data rows as labels
        row_labels = []
        for b in left_blocks:
            b_y = b.get("shape_position", {}).get("y", 0)
            best_match = None
            best_dist = 999

            for dr_idx, dr in enumerate(data_rows):
                if dr:
                    dr_y = dr[0].get("shape_position", {}).get("y", 0)
                    dist = abs(b_y - dr_y)
                    if dist < best_dist and dist < 0.1:
                        best_dist = dist
                        best_match = dr_idx

            if best_match is not None:
                b["semantic_role"] = "row_label"
                b["grid_role"] = f"row_label_{best_match + 1}"
                row_labels.append((best_match, b["text"]))
            else:
                b["semantic_role"] = "row_label"
                b["grid_role"] = f"row_label_{len(row_labels) + 1}"
                row_labels.append((len(row_labels), b["text"]))

        # Sort row labels by their matched row index
        row_labels.sort(key=lambda x: x[0])

        # Build grid structure
        grid = {
            "detected": True,
            "n_columns": len(header_row) if header_row else 0,
            "n_data_rows": len(data_rows),
            "headers": [b["text"] for b in header_row] if header_row else [],
            "data_rows": [[b["text"] for b in dr] for dr in data_rows],
            "row_labels": [lbl for _, lbl in row_labels],
        }

        slide_data["grid"] = grid
        slide_data["fingerprint"]["has_grid"] = True
        slide_data["fingerprint"]["grid_columns"] = grid["n_columns"]
        slide_data["fingerprint"]["grid_data_rows"] = grid["n_data_rows"]

        self.log.debug(f"    Grid: {grid['n_columns']} cols × {grid['n_data_rows']} rows")
        self.log.debug(f"    Headers: {grid['headers']}")
        self.log.debug(f"    Row labels: {grid['row_labels']}")
        for i, dr in enumerate(grid["data_rows"]):
            self.log.debug(f"    Data row {i+1}: {[c[:25]+'...' if len(c)>25 else c for c in dr]}")

    def _extract_shape(self, shape):
        info = {
            "shape_id": shape.shape_id,
            "name": shape.name,
            "type": self._classify_shape_type(shape),
            "position": normalize_position(
                shape.left, shape.top, shape.width, shape.height,
                self.slide_w, self.slide_h
            ),
            "position_emu": {
                "left": int(shape.left or 0), "top": int(shape.top or 0),
                "width": int(shape.width or 0), "height": int(shape.height or 0),
            },
            "position_inches": {
                "left": emu_to_inches(shape.left), "top": emu_to_inches(shape.top),
                "width": emu_to_inches(shape.width), "height": emu_to_inches(shape.height),
            },
            "rotation": shape.rotation if hasattr(shape, "rotation") else 0,
            "text_blocks": [],
        }

        if shape.is_placeholder:
            try:
                ph = shape.placeholder_format
                info["is_placeholder"] = True
                info["placeholder_idx"] = ph.idx
                info["placeholder_type"] = str(ph.type) if ph.type else None
            except Exception:
                info["is_placeholder"] = False
        else:
            info["is_placeholder"] = False

        if shape.has_text_frame:
            info["text_blocks"] = self._extract_text_frame(shape.text_frame, info["position"])
            info["full_text"] = shape.text_frame.text

        if shape.has_table:
            info["type"] = "table"
            info["table_data"] = self._extract_table(shape.table)

        try:
            info["auto_shape_type"] = str(shape.auto_shape_type)
        except (ValueError, AttributeError):
            pass

        try:
            if hasattr(shape, "fill") and shape.fill.type is not None:
                info["fill_type"] = str(shape.fill.type)
                if hasattr(shape.fill, "fore_color") and shape.fill.fore_color:
                    try:
                        info["fill_color"] = str(shape.fill.fore_color.rgb)
                    except Exception:
                        pass
        except Exception:
            pass

        return info

    def _classify_shape_type(self, shape):
        if shape.has_table: return "table"
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE: return "picture"
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP: return "group"
        if shape.shape_type == MSO_SHAPE_TYPE.CHART: return "chart"
        if shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE: return "autoshape"
        if shape.has_text_frame: return "textbox"
        if shape.shape_type == MSO_SHAPE_TYPE.FREEFORM: return "freeform"
        return "other"

    def _extract_text_frame(self, text_frame, shape_position):
        """
        Extract text from a text frame.
        
        KEY DESIGN: We treat each SHAPE as one text block (combining all paragraphs),
        not each paragraph separately. This preserves multi-line cell content
        as a single unit, which is essential for grid detection.
        """
        all_text_parts = []
        all_runs = []
        first_para_font = {}
        first_eff_size = None
        first_eff_bold = False
        first_alignment = None

        for para_idx, para in enumerate(text_frame.paragraphs):
            if not para.text.strip():
                continue

            if para_idx == 0 or not first_alignment:
                first_alignment = str(para.alignment) if para.alignment else None

            all_text_parts.append(para.text)

            # Collect runs
            for run in para.runs:
                all_runs.append({
                    "text": run.text,
                    "font": {
                        "name": run.font.name,
                        "size_pt": safe_font_size(run.font),
                        "bold": run.font.bold,
                        "italic": run.font.italic,
                        "underline": run.font.underline,
                        "color": safe_font_color(run.font),
                    },
                })

            # Capture first paragraph's font as the block default
            if not first_para_font:
                try:
                    first_para_font = {
                        "name": para.font.name,
                        "size_pt": safe_font_size(para.font),
                        "bold": para.font.bold,
                        "italic": para.font.italic,
                        "color": safe_font_color(para.font),
                    }
                except Exception:
                    first_para_font = {}

        if not all_text_parts:
            return []

        # Combine all paragraphs into one text block
        combined_text = "\n".join(all_text_parts)

        # Determine effective font size
        for r in all_runs:
            if r["font"]["size_pt"]:
                first_eff_size = r["font"]["size_pt"]
                break
        if not first_eff_size and first_para_font.get("size_pt"):
            first_eff_size = first_para_font["size_pt"]

        # Determine effective bold
        for r in all_runs:
            if r["font"]["bold"] is True:
                first_eff_bold = True
                break
        if not first_eff_bold and first_para_font.get("bold") is True:
            first_eff_bold = True

        # Classify role
        role = classify_text_role(
            combined_text, font_size=first_eff_size, position=shape_position,
            is_bold=first_eff_bold,
            shape_width_ratio=shape_position.get("w"),
            shape_height_ratio=shape_position.get("h"),
            alignment=first_alignment,
        )

        block = {
            "paragraph_index": 0,
            "text": combined_text,
            "level": 0,
            "alignment": first_alignment,
            "runs": all_runs,
            "shape_position": shape_position,
            "para_font": first_para_font,
            "semantic_role": role,
            "effective_font_size": first_eff_size,
        }

        return [block]

    def _extract_table(self, table):
        data = {
            "rows": len(table.rows), "cols": len(table.columns),
            "cells": [], "header_row": [], "data_rows": [],
        }
        for r_idx, row in enumerate(table.rows):
            row_data = []
            for c_idx in range(len(table.columns)):
                cell = table.cell(r_idx, c_idx)
                cell_info = {"row": r_idx, "col": c_idx, "text": cell.text, "paragraphs": []}
                for para in cell.text_frame.paragraphs:
                    pi = {"text": para.text, "runs": []}
                    for run in para.runs:
                        pi["runs"].append({
                            "text": run.text, "font_name": run.font.name,
                            "font_size": safe_font_size(run.font),
                            "bold": run.font.bold, "color": safe_font_color(run.font),
                        })
                    cell_info["paragraphs"].append(pi)
                try:
                    if cell.fill and cell.fill.type is not None:
                        cell_info["fill_color"] = str(cell.fill.fore_color.rgb)
                except Exception:
                    pass
                data["cells"].append(cell_info)
                row_data.append(cell.text)
            if r_idx == 0:
                data["header_row"] = row_data
            else:
                data["data_rows"].append(row_data)
        return data

    def _build_fingerprint(self, slide_data):
        content_types = set()
        positions = []
        for shape in slide_data["shapes"]:
            stype = shape["type"]
            if stype == "table":
                td = shape.get("table_data", {})
                content_types.add(f"table_{td.get('rows', 0)}x{td.get('cols', 0)}")
            elif stype == "picture":
                content_types.add("image")
            elif stype == "textbox":
                content_types.add("text")
            elif stype == "autoshape":
                content_types.add("shape")
            positions.append(shape["position"])

        text_positions = [
            tb["shape_position"] for tb in slide_data["text_blocks"]
            if tb.get("shape_position")
        ]
        col_count = detect_column_pattern(text_positions)

        roles = {}
        for tb in slide_data["text_blocks"]:
            role = tb.get("semantic_role", "unknown")
            roles[role] = roles.get(role, 0) + 1

        return {
            "content_types": sorted(list(content_types)),
            "text_block_count": len(slide_data["text_blocks"]),
            "shape_count": len(slide_data["shapes"]),
            "table_count": len(slide_data["tables"]),
            "image_count": len(slide_data["images"]),
            "column_pattern": col_count,
            "semantic_roles": roles,
            "has_table": len(slide_data["tables"]) > 0,
            "has_images": len(slide_data["images"]) > 0,
        }

    def _add_semantic_embeddings(self):
        all_texts, indices = [], []
        for s_idx, slide in enumerate(self.extracted_data["slides"]):
            for b_idx, block in enumerate(slide["text_blocks"]):
                text = block.get("text", "").strip()
                if text:
                    all_texts.append(text)
                    indices.append((s_idx, b_idx))
        if not all_texts:
            return

        self.log.info(f"Generating embeddings for {len(all_texts)} text blocks...")
        self.log.debug(f"Embedding model: {self.emb._model_name}")
        embeddings = self.emb.encode(all_texts)

        for (s_idx, b_idx), emb in zip(indices, embeddings):
            self.extracted_data["slides"][s_idx]["text_blocks"][b_idx]["embedding"] = emb.tolist()

        role_texts = list(ROLE_DESCRIPTORS.values())
        role_keys = list(ROLE_DESCRIPTORS.keys())
        role_embs = self.emb.encode(role_texts)
        self.extracted_data["metadata"]["role_embeddings"] = {
            k: e.tolist() for k, e in zip(role_keys, role_embs)
        }
        self.log.info("✓ Embeddings generated")

    def save_json(self, output_path="output/extracted_content.json"):
        def _clean(obj):
            if isinstance(obj, dict): return {k: _clean(v) for k, v in obj.items()}
            if isinstance(obj, list): return [_clean(v) for v in obj]
            if isinstance(obj, float):
                return None if obj != obj else round(obj, 6)
            return obj

        cleaned = _clean(self.extracted_data)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(cleaned, f, indent=2, ensure_ascii=False, default=str)
        self.log.info(f"✓ Extraction saved to {output_path}")
        return output_path