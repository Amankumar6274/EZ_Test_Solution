"""
src/utils.py
============
Shared utility functions: EMU conversions, color helpers, 
normalization, and embedding management.
"""

import numpy as np
from pptx.util import Emu
from src.logger import get_logger


# ─── EMU Conversions ────────────────────────────────────────────

EMU_PER_INCH = 914400
EMU_PER_PT = 12700


def emu_to_inches(emu_val):
    if emu_val is None:
        return 0.0
    return float(emu_val) / EMU_PER_INCH


def emu_to_pt(emu_val):
    if emu_val is None:
        return 0.0
    return float(emu_val) / EMU_PER_PT


def normalize_position(left, top, width, height, slide_w, slide_h):
    """Normalize shape position/size to [0,1] range relative to slide."""
    sw = float(slide_w) if slide_w else 1.0
    sh = float(slide_h) if slide_h else 1.0
    return {
        "x": float(left or 0) / sw,
        "y": float(top or 0) / sh,
        "w": float(width or 0) / sw,
        "h": float(height or 0) / sh,
        "cx": (float(left or 0) + float(width or 0) / 2) / sw,
        "cy": (float(top or 0) + float(height or 0) / 2) / sh,
    }


# ─── Color Helpers ──────────────────────────────────────────────

def rgb_to_tuple(rgb_color):
    if rgb_color is None:
        return None
    try:
        return (rgb_color[0], rgb_color[1], rgb_color[2])
    except (TypeError, IndexError):
        try:
            hex_str = str(rgb_color)
            if len(hex_str) == 6:
                return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
        except Exception:
            pass
    return None


def color_distance(c1, c2):
    if c1 is None or c2 is None:
        return 255.0 * 1.732
    return float(np.sqrt(sum((a - b) ** 2 for a, b in zip(c1, c2))))


def safe_font_color(font):
    try:
        if font.color and font.color.rgb:
            return rgb_to_tuple(font.color.rgb)
    except Exception:
        pass
    try:
        if font.color and font.color.theme_color is not None:
            return ("theme", str(font.color.theme_color))
    except Exception:
        pass
    return None


def safe_font_size(font):
    try:
        if font.size is not None:
            return float(font.size) / EMU_PER_PT
    except Exception:
        pass
    return None


# ─── Embedding Manager ──────────────────────────────────────────

class EmbeddingManager:
    """Lazy-loads sentence-transformers model for embeddings."""

    def __init__(self, model_name="all-MiniLM-L6-v2"):
        self._model_name = model_name
        self._model = None
        self.log = get_logger()

    def _load_model(self):
        if self._model is None:
            self.log.info("Loading sentence-transformer model...")
            self.log.debug(f"Model: {self._model_name}")
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._model_name)
            self.log.info(f"✓ Model loaded: {self._model_name}")

    def encode(self, texts):
        self._load_model()
        if not texts:
            return np.array([])
        return self._model.encode(texts, convert_to_numpy=True)

    def encode_single(self, text):
        self._load_model()
        return self._model.encode([text], convert_to_numpy=True)[0]

    def cosine_similarity(self, vec_a, vec_b):
        if vec_a is None or vec_b is None:
            return 0.0
        na = np.linalg.norm(vec_a)
        nb = np.linalg.norm(vec_b)
        if na == 0 or nb == 0:
            return 0.0
        return float(np.dot(vec_a, vec_b) / (na * nb))

    def batch_cosine_similarity(self, matrix_a, matrix_b):
        from sklearn.metrics.pairwise import cosine_similarity as cs
        if len(matrix_a) == 0 or len(matrix_b) == 0:
            return np.array([[]])
        return cs(matrix_a, matrix_b)


# ─── Content Role Classification ────────────────────────────────

ROLE_DESCRIPTORS = {
    "title": "main title heading of the presentation slide",
    "subtitle": "subtitle or secondary heading below the title",
    "body": "body text with detailed description or paragraphs",
    "bullet_list": "bullet pointed list of items or features",
    "table_header": "column header or category label in a data grid",
    "table_data": "data cells content inside a table row",
    "content_cell": "content text in a grid column below a header",
    "row_label": "row label like Point 1 or Point 2 on the left side",
    "metric_number": "large statistical number or key performance indicator",
    "metric_label": "short label describing a metric or statistic",
    "caption": "small caption or footnote text",
    "footer": "footer text with contact info or copyright",
}


def classify_text_role(text, font_size=None, position=None, is_bold=False,
                       shape_width_ratio=None, shape_height_ratio=None,
                       alignment=None):
    """
    Robust role classifier using multiple signals.
    Priority: position > font_size > shape_dimensions > content heuristics.
    """
    if not text or not text.strip():
        return "caption"

    t = text.strip()
    wc = len(t.split())
    y = position.get("y", 0.5) if position else 0.5
    x = position.get("x", 0.5) if position else 0.5
    w = position.get("w", 0.5) if position else (shape_width_ratio or 0.5)
    h = position.get("h", 0.2) if position else (shape_height_ratio or 0.2)
    is_centered = alignment and "CENTER" in str(alignment).upper()

    # ── Footer: bottom of slide ─────────────────────────────
    if y > 0.88:
        return "footer"

    # ── Title: large font at top of slide ───────────────────
    if font_size and font_size >= 20 and y < 0.2 and is_bold:
        return "title"
    if y < 0.12 and is_bold and w > 0.3:
        return "title"

    # ── Column header: narrow + bold + centered + in upper area ─
    # These are the key content headers in a grid layout
    if is_bold and w < 0.3 and 0.1 < y < 0.35 and is_centered:
        return "table_header"
    if is_bold and w < 0.3 and 0.1 < y < 0.35 and wc <= 4:
        return "table_header"

    # ── Subtitle: just below title, wider, not a column header
    if 0.1 < y < 0.3 and w > 0.3:
        if font_size and 14 <= font_size <= 22 and not is_bold:
            return "subtitle"
        if wc <= 15 and not is_bold:
            return "subtitle"

    # ── Row label: narrow, left side, short text, not centered
    if x < 0.15 and w < 0.15 and wc <= 4 and not is_centered:
        return "row_label"

    # ── Metric number: short numeric text ───────────────────
    stripped = t.replace("+", "").replace("%", "").replace(",", "").replace("/", "").replace(".", "").strip()
    is_numeric_like = stripped.isdigit() and wc <= 2
    is_short_with_symbols = wc <= 2 and any(c in t for c in "+%/") and any(c.isdigit() for c in t)

    if is_numeric_like or is_short_with_symbols:
        if w < 0.3:
            return "metric_number"
        if font_size and font_size >= 24:
            return "metric_number"
        if len(t) <= 5:
            return "metric_number"

    if font_size and font_size >= 30 and wc <= 3:
        return "metric_number"

    # ── Metric label: short bold text ───────────────────────
    if wc <= 5 and is_bold and 0.2 < y < 0.8:
        if font_size is None or (font_size and font_size <= 16):
            return "metric_label"

    # ── Caption/description: small font ─────────────────────
    if font_size and font_size <= 9:
        return "caption"

    # ── Content cell: narrow, center-aligned, in content area
    if w < 0.25 and y > 0.25 and is_centered:
        return "content_cell"
    if w < 0.25 and y > 0.25:
        return "content_cell"

    # ── Bullet list: multiple lines ─────────────────────────
    if "\n" in t and wc > 8:
        return "bullet_list"
    if wc > 30:
        return "body"

    return "body"


# ─── Spatial Utilities ──────────────────────────────────────────

def position_vector(norm_pos):
    return np.array([
        norm_pos.get("x", 0), norm_pos.get("y", 0),
        norm_pos.get("w", 0), norm_pos.get("h", 0),
        norm_pos.get("cx", 0), norm_pos.get("cy", 0),
    ])


def iou_1d(a_start, a_end, b_start, b_end):
    overlap = max(0, min(a_end, b_end) - max(a_start, b_start))
    union = max(a_end, b_end) - min(a_start, b_start)
    return overlap / union if union > 0 else 0.0


def iou_2d(pos_a, pos_b):
    x_iou = iou_1d(pos_a["x"], pos_a["x"] + pos_a["w"], pos_b["x"], pos_b["x"] + pos_b["w"])
    y_iou = iou_1d(pos_a["y"], pos_a["y"] + pos_a["h"], pos_b["y"], pos_b["y"] + pos_b["h"])
    return x_iou * y_iou


def detect_column_pattern(positions, threshold=0.15):
    if not positions:
        return 1
    cx_values = sorted([p["cx"] for p in positions])
    columns = [[cx_values[0]]]
    for cx in cx_values[1:]:
        if cx - columns[-1][-1] < threshold:
            columns[-1].append(cx)
        else:
            columns.append([cx])
    return len(columns)