"""
src/scorer.py
=============
Slide-level transparent scoring with Hungarian optimal assignment.

Scoring flow:
  1. ContentProfile analyzes input → derives dynamic weights
  2. For EACH (source_slide, template_slide) pair → compute 6 signal scores
  3. Build full score matrix [n_src × n_tmpl] — visible in logs
  4. Hungarian algorithm finds optimal 1-to-1 slide assignment
  5. Template score = weighted average of matched slide pair scores
  6. Full per-slide breakdown in report
"""

import json
import os
import numpy as np
from scipy.optimize import linear_sum_assignment

from src.logger import get_logger, log_table
from src.utils import (
    position_vector, iou_2d, EmbeddingManager, ROLE_DESCRIPTORS
)


# ═══════════════════════════════════════════════════════════════
#  COLUMN DETECTION
# ═══════════════════════════════════════════════════════════════

def detect_columns_from_positions(x_values, threshold=0.06):
    """Count columns by clustering x-positions."""
    if not x_values:
        return 1
    vals = sorted(x_values)
    columns = [[vals[0]]]
    for x in vals[1:]:
        if abs(x - np.mean(columns[-1])) < threshold:
            columns[-1].append(x)
        else:
            columns.append([x])
    return len(columns)


def detect_content_columns(slide_data, is_template=False):
    """Detect column count for a slide with multiple fallbacks."""
    items = slide_data.get("text_zones" if is_template else "text_blocks", [])

    x_values = []
    for item in items:
        pos = item.get("shape_position") or item.get("position") or {}
        x, y, w, h = pos.get("x", 0), pos.get("y", 0), pos.get("w", 0), pos.get("h", 0)
        if y < 0.16 or y > 0.88:
            continue
        if w > 0.55 or w < 0.01 or h < 0.005:
            continue
        if not is_template:
            role = item.get("semantic_role", "")
            if role in ("title", "subtitle", "footer"):
                continue
        x_values.append(round(x, 2))

    if x_values:
        return detect_columns_from_positions(x_values)

    # Fallback: table column count
    if not is_template:
        for tbl in slide_data.get("tables", []):
            return tbl.get("table_data", {}).get("cols", 1)
    else:
        for tz in slide_data.get("table_zones", []):
            return tz.get("table_cols", 1)

    return 1


def detect_slide_columns_with_fallbacks(slide_data, is_template=False):
    """Full column detection with narrow-block pattern fallback."""
    cols = detect_content_columns(slide_data, is_template)

    if cols <= 1 and not is_template:
        # Table fallback
        if slide_data["fingerprint"].get("has_table"):
            for tbl in slide_data.get("tables", []):
                cols = max(cols, tbl.get("table_data", {}).get("cols", 1))
        # Narrow-block card pattern fallback
        if cols <= 1:
            narrow = [b for b in slide_data.get("text_blocks", [])
                      if b.get("shape_position", {}).get("w", 1) < 0.25
                      and 0.15 < b.get("shape_position", {}).get("y", 0) < 0.85]
            if len(narrow) >= 6:
                xs = set(round(b["shape_position"]["x"], 2) for b in narrow
                         if "x" in b.get("shape_position", {}))
                if len(xs) >= 3:
                    cols = len(xs)
    return cols


# ═══════════════════════════════════════════════════════════════
#  CONTENT PROFILE
# ═══════════════════════════════════════════════════════════════

class ContentProfile:

    def __init__(self, extracted_content):
        self.content = extracted_content
        self.slides = extracted_content["slides"]
        self.log = get_logger()
        self.profile = {}
        self.slide_columns = []
        self.slide_types = []
        self._analyze()

    def _analyze(self):
        total_tables = sum(s["fingerprint"].get("table_count", 0) for s in self.slides)
        total_text = sum(s["fingerprint"].get("text_block_count", 0) for s in self.slides)

        self.slide_columns = []
        for s in self.slides:
            cols = detect_slide_columns_with_fallbacks(s, is_template=False)
            self.slide_columns.append(cols)

        # Classify each slide type
        self.slide_types = []
        for i, s in enumerate(self.slides):
            stype = self._classify_slide(s, self.slide_columns[i])
            self.slide_types.append(stype)

        max_cols = max(self.slide_columns, default=1)
        has_tables = total_tables > 0

        all_roles = {}
        for s in self.slides:
            for r, cnt in s["fingerprint"].get("semantic_roles", {}).items():
                all_roles[r] = all_roles.get(r, 0) + cnt

        has_metrics = all_roles.get("metric_number", 0) >= 2
        if not has_metrics:
            for s in self.slides:
                narrow = [b for b in s["text_blocks"]
                          if b.get("shape_position", {}).get("w", 1) < 0.25
                          and 0.15 < b.get("shape_position", {}).get("y", 0) < 0.85]
                if len(narrow) >= 8:
                    has_metrics = True
                    break

        self.profile = {
            "total_slides": len(self.slides),
            "total_tables": total_tables,
            "total_text_blocks": total_text,
            "max_columns": max_cols,
            "slide_columns": self.slide_columns,
            "slide_types": self.slide_types,
            "has_multi_column": max_cols >= 3,
            "has_tables": has_tables,
            "has_metrics": has_metrics,
            "role_distribution": all_roles,
        }

        self.log.info(f"Content profile:")
        for i, s in enumerate(self.slides):
            self.log.info(f"  Slide {i+1}: type={self.slide_types[i]}, "
                          f"cols={self.slide_columns[i]}, "
                          f"blocks={s['fingerprint'].get('text_block_count', 0)}, "
                          f"table={s['fingerprint'].get('has_table', False)}")

    def _classify_slide(self, slide, col_count):
        """Classify a slide into a type label."""
        fp = slide["fingerprint"]
        roles = fp.get("semantic_roles", {})
        n_blocks = fp.get("text_block_count", 0)
        has_table = fp.get("has_table", False)
        has_metrics = roles.get("metric_number", 0) >= 2

        # Check narrow-block pattern for metrics
        if not has_metrics:
            narrow = [b for b in slide.get("text_blocks", [])
                      if b.get("shape_position", {}).get("w", 1) < 0.25
                      and 0.15 < b.get("shape_position", {}).get("y", 0) < 0.85]
            if len(narrow) >= 8:
                has_metrics = True

        if has_table:
            return "table"
        if has_metrics:
            return f"metrics_{col_count}col"
        if col_count >= 5:
            return "grid_5"
        if col_count >= 3:
            return "grid_3"
        if n_blocks <= 4 and roles.get("title", 0) >= 1:
            return "title"
        return "body"

    def compute_dynamic_weights(self):
        p = self.profile
        w = {
            "column_match": 20,
            "zone_count_fit": 10,
            "table_fit": 5,
            "spatial_overlap": 15,
            "semantic_role_fit": 10,
            "layout_type_match": 10,
        }
        if p["has_multi_column"]:
            w["column_match"] += 25
            w["spatial_overlap"] += 5
        if p["has_tables"]:
            w["table_fit"] += 20
        if p["has_metrics"]:
            w["zone_count_fit"] += 10
            w["column_match"] += 5

        total = sum(w.values())
        weights = {k: round(v / total, 4) for k, v in w.items()}
        diff = 1.0 - sum(weights.values())
        if abs(diff) > 0.0001:
            weights[list(weights.keys())[0]] = round(weights[list(weights.keys())[0]] + diff, 4)

        self.log.info("Dynamic weights:")
        for k, v in weights.items():
            pct = int(v * 100)
            bar = "█" * (pct // 3) + "░" * (33 - pct // 3)
            self.log.info(f"  {k:<22} {bar} {pct}%")
        return weights


# ═══════════════════════════════════════════════════════════════
#  SLIDE-PAIR SCORER
# ═══════════════════════════════════════════════════════════════

class SlidePairScorer:

    def __init__(self, src_slide, tmpl_slide, src_col_count=None, src_type=None):
        self.src = src_slide
        self.tmpl = tmpl_slide
        self.src_fp = src_slide["fingerprint"]
        self.tmpl_fp = tmpl_slide["fingerprint"]
        self.src_cols = src_col_count
        self.src_type = src_type

    def score_all_signals(self):
        return {
            "column_match": self._column_match(),
            "zone_count_fit": self._zone_count_fit(),
            "table_fit": self._table_fit(),
            "spatial_overlap": self._spatial_overlap(),
            "semantic_role_fit": self._semantic_role_fit(),
            "layout_type_match": self._layout_type_match(),
        }

    def _get_src_cols(self):
        c = self.src_cols or detect_slide_columns_with_fallbacks(self.src, False)
        return c

    def _get_tmpl_cols(self):
        c = detect_content_columns(self.tmpl, is_template=True)
        if c <= 1:
            for tz in self.tmpl.get("table_zones", []):
                c = max(c, tz.get("table_cols", 1))
        if c <= 1:
            narrow = [z for z in self.tmpl.get("text_zones", [])
                      if z.get("position", {}).get("w", 1) < 0.25
                      and 0.15 < z.get("position", {}).get("y", 0) < 0.85]
            if len(narrow) >= 6:
                xs = set(round(z["position"]["x"], 2) for z in narrow)
                if len(xs) >= 3:
                    c = len(xs)
        return c

    def _column_match(self):
        src_c = self._get_src_cols()
        tmpl_c = self._get_tmpl_cols()
        if src_c == tmpl_c:
            return 1.0
        diff = abs(src_c - tmpl_c)
        if diff == 1: return 0.4
        if diff == 2: return 0.15
        return 0.0

    def _zone_count_fit(self):
        src_n = self.src_fp.get("text_block_count", 0)
        tmpl_n = self.tmpl_fp.get("text_zone_count", 0)
        if src_n == 0: return 0.5
        if tmpl_n == 0: return 0.0
        return min(src_n, tmpl_n) / max(src_n, tmpl_n)

    def _table_fit(self):
        src_t = self.src_fp.get("has_table", False)
        tmpl_t = self.tmpl_fp.get("has_table", False)
        if not src_t and not tmpl_t: return 1.0
        if not src_t and tmpl_t: return 0.7
        if src_t and tmpl_t:
            src_tables = self.src.get("tables", [])
            tmpl_zones = self.tmpl.get("table_zones", [])
            if src_tables and tmpl_zones:
                sc = src_tables[0].get("table_data", {}).get("cols", 5)
                tc = tmpl_zones[0].get("table_cols", 5)
                if sc == tc: return 1.0
                return max(0.4, 1.0 - abs(sc - tc) * 0.15)
            return 0.8
        return 0.0

    def _spatial_overlap(self):
        src_blocks = self.src.get("text_blocks", [])
        tmpl_zones = self.tmpl.get("text_zones", [])
        def _filt(items, key):
            return [item.get(key, item.get("position", {}))
                    for item in items
                    if 0.12 < item.get(key, item.get("position", {})).get("y", 0) < 0.9
                    and item.get(key, item.get("position", {})).get("w", 0) > 0.01]
        sp = _filt(src_blocks, "shape_position")
        tp = _filt(tmpl_zones, "position")
        if not sp or not tp: return 0.3
        total = sum(max(iou_2d(s, t) for t in tp) for s in sp)
        return min(total / len(sp) * 4.0, 1.0)

    def _semantic_role_fit(self):
        src_roles = self.src_fp.get("semantic_roles", {})
        if not src_roles: return 0.5
        tmpl_zones = self.tmpl.get("text_zones", [])
        if not tmpl_zones: return 0.1
        score, checks = 0.0, 0
        for role, count in src_roles.items():
            if role in ("title", "subtitle"):
                top = [z for z in tmpl_zones if z["position"].get("y", 1) < 0.18]
                score += 1.0 if any(z.get("is_bold") or (z.get("font_size") and z["font_size"] > 20) for z in top) else 0.2
                checks += 1
            elif role in ("body", "bullet_list"):
                mid = [z for z in tmpl_zones if 0.15 < z["position"].get("y", 0) < 0.9]
                score += min(len(mid) / max(count, 1), 1.0)
                checks += 1
            elif role in ("metric_number", "metric_label"):
                mid = [z for z in tmpl_zones if 0.15 < z["position"].get("y", 0) < 0.85]
                score += min(len(mid) / max(count, 1), 1.0)
                checks += 1
            elif role == "footer":
                score += 1.0 if [z for z in tmpl_zones if z["position"].get("y", 0) > 0.85] else 0.2
                checks += 1
        return score / max(checks, 1)

    def _layout_type_match(self):
        src_c = self._get_src_cols()
        tmpl_c = self._get_tmpl_cols()
        src_t = self.src_fp.get("has_table", False)
        tmpl_t = self.tmpl_fp.get("has_table", False)
        n_src = self.src_fp.get("text_block_count", 0)
        n_tmpl = self.tmpl_fp.get("text_zone_count", 0)

        def _cls(c, ht, n):
            if ht: return "table"
            if c >= 5: return "grid_5"
            if c >= 3: return "grid_3"
            if c == 2: return "split_2"
            if n <= 3: return "title"
            return "body"

        st = self.src_type or _cls(src_c, src_t, n_src)
        tt = _cls(tmpl_c, tmpl_t, n_tmpl)
        if st == tt: return 1.0
        compat = {
            ("grid_5", "grid_3"): 0.3, ("grid_3", "grid_5"): 0.3,
            ("grid_5", "split_2"): 0.1, ("grid_5", "body"): 0.1,
            ("grid_3", "split_2"): 0.3, ("table", "body"): 0.2,
            ("body", "body"): 1.0, ("title", "title"): 1.0, ("title", "body"): 0.5,
            ("metrics_5col", "grid_5"): 0.8, ("grid_5", "metrics_5col"): 0.8,
            ("metrics_5col", "grid_3"): 0.2, ("metrics_5col", "body"): 0.1,
        }
        return compat.get((st, tt), 0.1)


# ═══════════════════════════════════════════════════════════════
#  MAIN SCORER — full matrix + per-slide transparency
# ═══════════════════════════════════════════════════════════════

class TemplateScorer:

    def __init__(self, extracted_content, template_analyses,
                 embedding_manager=None, custom_weights=None):
        self.content = extracted_content
        self.templates = template_analyses
        self.emb = embedding_manager or EmbeddingManager()
        self.custom_weights = custom_weights
        self.scores = []
        self.log = get_logger()
        self.profile = ContentProfile(extracted_content)
        self.weights = custom_weights if custom_weights else self.profile.compute_dynamic_weights()

    def score_all(self):
        self.log.info(f"\nScoring {len(self.templates)} templates × "
                      f"{len(self.content['slides'])} slides...\n")

        for tmpl in self.templates:
            result = self._score_template(tmpl)
            self.scores.append(result)
            self._log_slide_matches(result)

        self.scores.sort(key=lambda x: x["total_score"], reverse=True)

        # Summary table
        self.log.info("\n  ═══ FINAL RANKING ═══")
        headers = ["#", "Template", "Score", "Col", "Zone", "Tbl", "Spat", "Sem", "Lay"]
        rows = []
        for i, s in enumerate(self.scores):
            f = s["slide_pair_avg"]
            marker = " ★" if i == 0 else ""
            rows.append([
                i + 1, s["template_name"][:25], f"{s['total_score']:.3f}{marker}",
                f"{f.get('column_match', 0):.2f}", f"{f.get('zone_count_fit', 0):.2f}",
                f"{f.get('table_fit', 0):.2f}", f"{f.get('spatial_overlap', 0):.2f}",
                f"{f.get('semantic_role_fit', 0):.2f}", f"{f.get('layout_type_match', 0):.2f}",
            ])
        log_table(headers, rows, col_widths=[4, 27, 12, 6, 6, 6, 6, 6, 6])
        return self.scores

    def _log_slide_matches(self, result):
        """Log per-slide match details for a template."""
        name = result["template_name"]
        self.log.info(f"\n  ── {name} (score={result['total_score']:.4f}) ──")
        for match in result["slide_matches"]:
            si = match["source_slide"]
            ti = match["template_slide"]
            sc = match["score"]
            st = match["source_type"]
            signals = match["signals"]
            sig_str = " | ".join(f"{k[:3]}={v:.2f}" for k, v in signals.items())
            self.log.info(f"    Src {si} ({st:>12}) → Tmpl {ti}  "
                          f"score={sc:.3f}  [{sig_str}]")

    def get_best_template(self):
        if not self.scores: self.score_all()
        return self.scores[0]

    def _score_template(self, tmpl):
        src_slides = self.content["slides"]
        tmpl_slides = tmpl["slides"]
        n_src, n_tmpl = len(src_slides), len(tmpl_slides)

        # Build full score matrix
        score_matrix = np.zeros((n_src, n_tmpl))
        signal_matrix = [[None] * n_tmpl for _ in range(n_src)]

        for i in range(n_src):
            src_cols = self.profile.slide_columns[i]
            src_type = self.profile.slide_types[i]
            for j in range(n_tmpl):
                sp = SlidePairScorer(src_slides[i], tmpl_slides[j],
                                     src_col_count=src_cols, src_type=src_type)
                signals = sp.score_all_signals()
                signal_matrix[i][j] = signals
                score_matrix[i][j] = sum(self.weights.get(k, 0) * v
                                         for k, v in signals.items())

        # Log full matrix
        self.log.debug(f"  Score matrix for {tmpl['template_name']}:")
        header_row = "       " + "  ".join(f"T{j+1:>4}" for j in range(n_tmpl))
        self.log.debug(f"    {header_row}")
        for i in range(n_src):
            vals = "  ".join(f"{score_matrix[i][j]:.3f}" for j in range(n_tmpl))
            st = self.profile.slide_types[i]
            self.log.debug(f"    S{i+1} ({st:>8}): {vals}")

        # Hungarian assignment
        n = max(n_src, n_tmpl)
        padded = np.zeros((n, n))
        padded[:n_src, :n_tmpl] = score_matrix
        row_ind, col_ind = linear_sum_assignment(-padded)

        # Build per-slide match results
        slide_matches = []
        matched_scores = []
        assignments = []
        for r, c in zip(row_ind, col_ind):
            if r < n_src and c < n_tmpl:
                matched_scores.append(score_matrix[r][c])
                assignments.append((r, c))
                slide_matches.append({
                    "source_slide": r + 1,
                    "template_slide": c + 1,
                    "source_type": self.profile.slide_types[r],
                    "source_cols": self.profile.slide_columns[r],
                    "score": round(float(score_matrix[r][c]), 4),
                    "signals": {k: round(v, 4) for k, v in signal_matrix[r][c].items()},
                })

        total = float(np.mean(matched_scores)) if matched_scores else 0.0

        # Coverage penalty
        coverage = min(n_tmpl, n_src) / max(n_src, 1)
        if coverage < 1.0:
            total *= (0.7 + 0.3 * coverage)

        # Average signals for summary
        avg_signals = {}
        if slide_matches:
            for key in slide_matches[0]["signals"]:
                avg_signals[key] = float(np.mean([m["signals"][key] for m in slide_matches]))

        return {
            "template_name": tmpl["template_name"],
            "template_path": tmpl["template_path"],
            "total_score": round(total, 4),
            "slide_pair_avg": {k: round(v, 4) for k, v in avg_signals.items()},
            "slide_matches": slide_matches,
            "assignments": assignments,
            "score_matrix": score_matrix.tolist(),
            "dynamic_weights": self.weights,
            "content_profile": self.profile.profile,
        }

    def save_report(self, output_path="output/scoring_report.json"):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        # Build readable report
        report = {
            "dynamic_weights": self.weights,
            "content_profile": self.profile.profile,
            "source_slide_analysis": [
                {
                    "slide": i + 1,
                    "type": self.profile.slide_types[i],
                    "columns": self.profile.slide_columns[i],
                    "text_blocks": self.content["slides"][i]["fingerprint"].get("text_block_count", 0),
                    "has_table": self.content["slides"][i]["fingerprint"].get("has_table", False),
                    "roles": self.content["slides"][i]["fingerprint"].get("semantic_roles", {}),
                }
                for i in range(len(self.content["slides"]))
            ],
            "template_rankings": [
                {
                    "rank": i + 1,
                    "template": s["template_name"],
                    "total_score": s["total_score"],
                    "avg_signals": s["slide_pair_avg"],
                    "slide_matches": s["slide_matches"],
                    "score_matrix": s["score_matrix"],
                }
                for i, s in enumerate(self.scores)
            ],
            "selected_template": self.scores[0]["template_name"] if self.scores else None,
            "selection_reasoning": self._generate_reasoning(),
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, default=str)
        self.log.info(f"✓ Scoring report saved to {output_path}")

        if self.scores:
            with open("output/selected_template.txt", "w") as f:
                f.write(self.scores[0]["template_name"])
            self.log.info(f"✓ Selected template: output/selected_template.txt")
        return report

    def _generate_reasoning(self):
        if not self.scores: return "No templates scored."
        best = self.scores[0]
        lines = [f"Selected '{best['template_name']}' (score={best['total_score']:.4f})."]
        lines.append(f"Matched {len(best['slide_matches'])} slide pairs:")
        for m in best["slide_matches"]:
            lines.append(f"  Src slide {m['source_slide']} ({m['source_type']}) "
                         f"→ Tmpl slide {m['template_slide']} "
                         f"(score={m['score']:.3f})")
        sigs = best["slide_pair_avg"]
        best_sig = max(sigs, key=sigs.get)
        worst_sig = min(sigs, key=sigs.get)
        lines.append(f"Strongest signal: {best_sig}={sigs[best_sig]:.2f}")
        lines.append(f"Weakest signal: {worst_sig}={sigs[worst_sig]:.2f}")

        p = self.profile.profile
        if p["has_multi_column"]:
            lines.append(f"Content has {p['max_columns']}-column layouts → column_match weighted highest")
        if p["has_tables"]:
            lines.append(f"Content has tables → table_fit boosted")
        if p["has_metrics"]:
            lines.append(f"Content has metric/stats → zone_count boosted")

        if len(self.scores) > 1:
            ru = self.scores[1]
            lines.append(f"Runner-up: '{ru['template_name']}' "
                         f"(score={ru['total_score']:.4f}, "
                         f"margin={best['total_score'] - ru['total_score']:.4f})")
        return " ".join(lines)